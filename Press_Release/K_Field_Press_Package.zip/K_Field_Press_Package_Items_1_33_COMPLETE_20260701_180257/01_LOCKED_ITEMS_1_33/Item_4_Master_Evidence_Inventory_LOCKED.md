# Item 4 — Master Evidence Inventory v2 — LOCKED

The controlling Item 4 evidence ledger is included in full under `01_SOURCE_MATERIALS/`:

- `K_field_Item4_Master_Evidence_Inventory_v2(1).docx`
- `K_field_Item4_Master_Evidence_Inventory_v2(1).md`
- `K_field_Item4_Evidence_Ledger_v2(1).csv`
- `K_field_Item4_Discovery_Hierarchy(1).pdf`
- `K_field_Item4_Executive_Summary(1).pdf`
- `K_field_Item4_Importance_Matrix(1).pdf`

## Current controlling structure

This v2 inventory preserves all 84 original evidence records, adds Importance classification, distinguishes Mass Bridge from Geometric Lock, splits Act III into Act IIIA and Act IIIB, and renames the graph as the Discovery Dependency Graph.

## Controlling discovery flow

Observation -> Geometric Extraction -> Mass Bridge -> Geometric Lock -> Geometric Generation -> Computational Validation -> Engineering.

Expanded hierarchy:

Observation -> Structural Recurrence -> Geometric Extraction -> Mass Bridge -> Geometric Lock -> Generative Hierarchy -> Computed Physics -> Validation -> Engineering.

## Category model

Category A — Discovery Evidence: defines the K-field, extracted geometric context, Mass Bridge, Geometric Lock, and transition into generation.

Category B — Validation Evidence: organizes generated mathematics, computational validation, domain mapping, conditional branches, engineering direction, and open gates.

## Act model

Act I — Discovery by Observation.
Act II — Discovery by Physical Lock.
Geometric Lock — state created by the Mass Bridge.
Act IIIA — Geometric Generation.
Act IIIB — Computational Validation.
Engineering.
Open Research.

## Public-release boundary

Public documents use Category A, Core Discovery, Primary Discovery, Communications, Engineering, and tightly selected role-boundary statements. Technical documents carry Primary Validation and Supporting Validation. Conditional and Open Research records remain controlled until dependencies close.
