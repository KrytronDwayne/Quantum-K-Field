# Item 19 — Caption and Attribution Sheet — LOCKED

Status: LOCKED by user approval.  
Target use: Press kit images, website graphics, journalist downloads, social previews, technical diagrams, investigator photo assets, presentation images, and media republication workflows.  
Source basis: Locked Items 1-18, especially the locked press release image set specification, primary discovery graphic production brief, technical diagram set production brief, investigator photo assets specification, primary press release, public technical backgrounder, FAQ, public glossary, and comparison sheet.  
Public boundary: This sheet controls captions, credits, usage statements, and attribution language only. It does not disclose proprietary geometry, exact derivations, witness tables, orientation data, internal computational machinery, unreleased devices, or trade-secret technical details.

---

# Caption and Attribution Sheet

## Purpose

This sheet provides controlled captions, credit lines, alt text, usage statements, and attribution language for visual assets in the K-field press release package. Its purpose is to make images easy for journalists and web editors to use while preserving message discipline, publication rights, and the public/reserved technical boundary.

Every visual asset should be distributed with a short caption, optional long caption, credit line, usage-rights statement, alt text, and version identifier. Captions should support the approved public explanation without introducing speculative claims, unapproved technical details, or visual overinterpretation.

## Universal caption principles

Captions should be accurate, restrained, and publication-ready. They should explain what the image represents, not claim that a graphic proves the discovery. The preferred framing is “represents,” “presents,” “shows,” “illustrates,” or “visualizes,” depending on context.

Avoid captions that imply:
- A finished commercial product
- Released proprietary derivations
- Anti-gravity capability
- Free-energy technology
- Metaphysical or religious interpretation
- Institutional endorsement not present in the approved materials
- Proof beyond the controlled public evidence package
- Exact disclosure of protected geometry or numerical witness construction

## Universal credit line

Use this credit line for all K-field discovery graphics, diagrams, and visual press materials unless a specific photographer or designer credit is required:

“Image credit: Krytronx, LLC / K-field Discovery Press Materials.”

Use this credit line for investigator portraits unless a specific photographer credit supersedes it:

“Photo credit: Krytronx, LLC / K-field Discovery Press Materials.”

If a photographer or external designer is credited later, use this structure:

“Photo credit: [Photographer Name] / Krytronx, LLC.”

or

“Image credit: [Designer Name] / Krytronx, LLC / K-field Discovery Press Materials.”

Do not invent photographer, designer, agency, institutional, or publication credits.

## Universal usage-rights statement

Use this statement for visual press assets unless a more restrictive rights notice is later approved:

“Approved for use in coverage of the K-field discovery announcement. Do not alter in ways that imply a completed commercial product, released proprietary derivation, anti-gravity device, free-energy claim, metaphysical interpretation, institutional endorsement not stated in the approved materials, or exact disclosure of protected geometry.”

Short rights version:

“Approved for editorial use in coverage of the K-field discovery announcement. Do not alter in ways that change the approved meaning or imply unsupported claims.”

## Required attribution metadata fields

Each released image or diagram should carry the following metadata in the press kit index:

| Field | Requirement |
|---|---|
| Asset ID | Required |
| Filename | Required |
| Asset type | Graphic, diagram, portrait, social asset, presentation asset, or other |
| Version date | Required |
| Caption short | Required |
| Caption long | Optional but recommended |
| Credit line | Required |
| Usage-rights statement | Required |
| Alt text | Required |
| Approved publication context | Required |
| Restricted use notes | Required where applicable |

## Primary discovery graphic captions

Asset IDs:
- IMG-01A — Primary discovery graphic, square
- IMG-01B — Primary discovery graphic, landscape
- IMG-01C — Primary discovery graphic, print master

Short caption:

“The K-field is presented as a discovered geometric foundation beneath known physical branches, physically anchored by the Mass Bridge.”

Long caption:

“This primary discovery graphic represents the K-field as a structured geometric foundation beneath known physics. The central Mass Bridge motif marks the public focal point of the discovery narrative: the transition where independently extracted geometry becomes physically anchored to matter, allowing later physical relationships to be treated as downstream witnesses of the fixed structure.”

Alt text:

“Scientific visualization showing an ordered geometric foundation labeled as the K-field beneath branching domains of known physics, connected by a central Mass Bridge structure.”

Restricted use notes:

Do not crop or alter in ways that remove the Mass Bridge anchor, obscure the K-field foundation layer, or imply a completed device or product.

## Mass Bridge visual captions

Asset ID:
- IMG-03 — Mass Bridge visual

Short caption:

“The Mass Bridge is the public focal point of the discovery narrative because it physically anchors the extracted geometry.”

Long caption:

“This visual represents the Mass Bridge as the anchoring hinge between extracted geometric structure and physical matter. In the public press package, the Mass Bridge is used as the focal point for explaining how the investigation moved from observation into computation while preserving proprietary derivation details.”

Alt text:

“Technical visual showing a central Mass Bridge structure connecting extracted geometry to a physical anchor.”

Restricted use notes:

Do not add exact mass-ratio numbers, witness values, formulas, or derivation steps to this image.

## Branch expression diagram captions

Asset IDs:
- IMG-04 — Branch expression diagram
- DIA-03 — Branch expression diagram

Short caption:

“Known physical domains are presented as branch expressions of a deeper geometric foundation.”

Long caption:

“This diagram represents time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange as organized branch expressions of the K-field foundation. It is a public explanatory diagram and does not disclose proprietary branch-generation rules or internal computational machinery.”

Alt text:

“Diagram showing the K-field foundation branching into time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange.”

Restricted use notes:

Do not recolor branches into an uncontrolled rainbow palette or alter the diagram to imply that known physics is being replaced rather than organized at a deeper foundational level.

## Scale bridge visual captions

Asset IDs:
- IMG-05 — Scale bridge visual
- DIA-05 — Scale bridge diagram

Short caption:

“The K-field framework is presented as scale-spanning, connecting local structure with larger physical organization.”

Long caption:

“This visual represents the K-field framework as scale-spanning, with a common structured motif extending from local geometric organization through material-scale structure and larger physical organization. It is intended as a public explanation of scale continuity, not a claim of completed engineering deployment.”

Alt text:

“Scale-spanning visual showing a structured geometric motif connecting local, material, and larger physical organization.”

Restricted use notes:

Do not alter in ways that imply a spacecraft engine, anti-gravity craft, free-energy system, or finished propulsion technology.

## Public simple visual captions

Asset ID:
- IMG-06 — Public simple visual

Short caption:

“A simplified public explanation: the K-field is the foundation, and known physics appears as branch-level expression.”

Long caption:

“This simplified visual presents the K-field as the lower foundational layer and known physics as an organized upper branch layer. The image is designed for general readers and social media contexts where minimal text and immediate hierarchy are required.”

Alt text:

“Simple visual showing the K-field foundation beneath known physics with a central bridge.”

Restricted use notes:

Do not add speculative claims, equations, device imagery, or unapproved slogans.

## Technical lattice abstract captions

Asset ID:
- IMG-07 — Technical lattice abstract

Short caption:

“Abstract representation of structured geometry used as public visual language for the K-field framework.”

Long caption:

“This abstract visual uses structured geometry as public-facing visual language for the K-field framework. It is intentionally non-reconstructive and does not show protected geometry, exact cell measurements, orientation data, or derivation pathways.”

Alt text:

“Abstract technical lattice with structured geometric depth.”

Restricted use notes:

Do not label this image as the exact K-field geometry. Do not use it as a technical proof diagram.

## Discovery story visual captions

Asset IDs:
- IMG-08 — Discovery story visual
- DIA-04 — Discovery sequence diagram

Short caption:

“The discovery path moved from observation to structural extraction, then to physical anchoring through the Mass Bridge and downstream witness expansion.”

Long caption:

“This discovery sequence visual summarizes the public investigative arc: direction-dependent observations, structural extraction, Mass Bridge / Geometric Lock, and downstream witness expansion. It is intended as a public narrative aid, not a complete derivation map.”

Alt text:

“Four-stage diagram showing observation, structure, Mass Bridge, and witnesses.”

Restricted use notes:

Do not add exact observation coordinates, proprietary construction steps, or witness tables.

## Foundation hierarchy diagram captions

Asset ID:
- DIA-01 — K-field foundation hierarchy diagram

Short caption:

“The K-field is presented as a discovered geometric foundation beneath known physics, with the Mass Bridge serving as the public anchoring hinge.”

Long caption:

“This hierarchy diagram shows the public architecture of the K-field discovery: a lower structured foundation, a central Mass Bridge anchor, and upper known physical branches. The diagram is explanatory and does not disclose protected derivation machinery.”

Alt text:

“Hierarchy diagram showing the K-field foundation below, the Mass Bridge in the center, and known physics above.”

Restricted use notes:

Do not alter the hierarchy so that the K-field appears as one force beside other forces.

## Mass Bridge anchor diagram captions

Asset ID:
- DIA-02 — Mass Bridge anchor diagram

Short caption:

“The Mass Bridge marks the transition where extracted geometry becomes physically anchored.”

Long caption:

“This diagram represents the Mass Bridge as the public anchor between extracted geometry and physical matter. It supports the approved explanation that downstream physical relationships are treated as witnesses of the fixed structure after the geometry becomes physically anchored.”

Alt text:

“Diagram showing extracted geometry connected through the Mass Bridge to a physical anchor and downstream witnesses.”

Restricted use notes:

Do not add protected numerical values, exact ratios, derivation steps, or reconstructive geometry.

## Public vs reserved boundary diagram captions

Asset ID:
- DIA-06 — Public vs reserved boundary diagram

Short caption:

“The public press package explains the discovery while preserving proprietary derivation details as reserved technical material.”

Long caption:

“This diagram shows the distinction between public release materials and reserved technical materials. Public materials explain the K-field discovery, its hierarchy, its Mass Bridge focal point, and its significance; reserved materials include proprietary geometry, internal derivation pathways, projection/compiler machinery, and witness construction.”

Alt text:

“Diagram separating public K-field press materials from reserved proprietary technical derivation materials.”

Restricted use notes:

Do not make this diagram look like hidden evidence, secrecy for lack of support, legal threat, or classified government material.

## Investigator portrait captions

Asset IDs:
- PHOTO-01 — Press headshot, square
- PHOTO-02 — Press headshot, vertical
- PHOTO-03 — Research portrait, landscape
- PHOTO-04 — Neutral portrait
- PHOTO-05 — Interview thumbnail

Short caption:

“P. Dwayne Esterline, Principal of Krytronx, LLC and discoverer of the K-field.”

Long caption:

“P. Dwayne Esterline is the owner and Principal of Krytronx, LLC, an independent research firm focused on further development of the K-field discovery. The K-field is presented in the press package as a discovered geometric foundation beneath known physics, physically anchored by the Mass Bridge.”

Alt text:

“Portrait of P. Dwayne Esterline, Principal of Krytronx, LLC and discoverer of the K-field.”

Restricted use notes:

Do not crop or edit portraits in ways that imply institutional affiliation, political endorsement, product endorsement, or claims outside the approved press package.

## Caption language matrix

| Avoid | Preferred |
|---|---|
| “This proves a new force exists.” | “This visual presents the K-field as a discovered geometric foundation beneath known physics.” |
| “Anti-gravity technology.” | “Potential field-coupled technology pathways.” |
| “Free energy system.” | “Energy exchange as a branch expression.” |
| “Secret formula hidden from the public.” | “Reserved proprietary derivation details.” |
| “Mystical geometry.” | “Structured geometric foundation.” |
| “Replacement for physics.” | “Deeper foundation beneath known physical branches.” |
| “Device image.” | “Public explanatory visual.” |
| “Exact K-field geometry.” | “Abstract public representation of structured geometry.” |
| “Inventor claims.” | “Press package materials present the discovery framework.” |
| “Cosmic portal.” | “Foundation-to-branch hierarchy.” |

## Social and web caption variants

Short social caption:

“The K-field is presented as a discovered geometric foundation beneath known physics, with the Mass Bridge as the public anchoring point.”

Website hero caption:

“The K-field discovery is presented through a foundation-to-branch hierarchy: structured geometry beneath known physics, physically anchored by the Mass Bridge.”

Download-page caption:

“These approved press images, diagrams, and portraits are provided for editorial use in coverage of the K-field discovery announcement.”

Technical-backgrounder caption:

“Public diagrams explain the hierarchy and discovery sequence while reserving proprietary derivation details.”

## File naming and version control

Use stable filenames from the locked production briefs. Add version suffixes only when needed.

Recommended version suffix:
`_vYYYYMMDD`

Example:
`k_field_primary_discovery_graphic_square_v20260701.png`

Do not rename files in ways that suggest a different claim, product, or technical disclosure. Avoid filenames such as:
- `anti_gravity_engine.png`
- `free_energy_device.png`
- `secret_formula.png`
- `proof_of_everything.png`
- `exact_kfield_geometry.png`

## Approval rule

Captions and attribution statements should be approved before final public image release. If the image changes materially, the caption should be rechecked against the altered image. If a publisher edits a caption, preferred correction language should restore the approved public framing: K-field foundation, Mass Bridge anchor, known physics branches, public/reserved boundary.

---

Lock status: Approved by user and locked on 2026-07-01T17:27:14+00:00.
