# Item 31 — Citation and Document Index — LOCKED

Status: LOCKED by user approval.  
Target use: Public press-kit document index, landing page document inventory, downloadable ZIP manifest support, editorial reference, internal continuity, final package audit, and media navigation.  
Source basis: Locked Items 1-30, especially the Downloadable Press Kit ZIP Specification, Landing Page, Caption and Attribution Sheet, Media Contact Sheet, Embargo and Release Instructions, Quote Sheet, Public Technical Backgrounder, FAQ, and all public-facing package items.  
Public boundary: This index identifies documents, recommended file names, public/restricted status, and release locations. It does not disclose proprietary geometry, exact derivation pathways, orientation data, witness tables, internal branch-generation rules, projection/compiler machinery, unreleased devices, private contact details, or trade-secret technical material.

---

# Citation and Document Index

## Purpose

This index provides a clean inventory of K-field discovery press package materials. It identifies each document’s title, type, status, recommended filename, public/restricted classification, and recommended location in the public or internal package.

The index should be used to support the landing page, downloadable press kit ZIP, internal master package, final package audit, and media navigation.

## Controlling rule

The public press kit should include only public-approved materials. Internal controls, drafts, source archives, audit files, reserved derivation files, and private-contact materials should remain outside the public ZIP unless separately approved.

## Index version

Index status: Draft  
Generated UTC: 2026-07-01T17:54:43+00:00  
Current build item: Item 31  
Last locked item: Item 30  
Approved landing-page title: “K-field Discovery Announcement”

## Recommended public document hierarchy

```text
K_Field_Discovery_Press_Kit_PUBLIC_vYYYYMMDD/
  00_README/
  01_CORE_ANNOUNCEMENT/
  02_PUBLIC_EXPLANATION/
  03_TECHNICAL_PUBLIC_BACKGROUND/
  04_INVESTIGATOR_AND_ORGANIZATION/
  05_QUOTES_AND_MEDIA_QA/
  06_VISUAL_ASSETS/
  07_MEDIA_OPERATIONS/
  08_INDEX_AND_ATTRIBUTION/
```

## Document index

| Item | Document Title | Type | Public / Restricted Status | Recommended Public Filename | Recommended Location |
|---:|---|---|---|---|---|
| 1 | Master Message Framework | Messaging control document | Restricted internal control | `Item_1_Master_Message_Framework_LOCKED.md` | Internal master package only |
| 2 | Controlled Glossary | Terminology control document | Restricted internal control; public derivative exists as Item 13 | `Item_2_Controlled_Glossary_LOCKED.md` | Internal master package only |
| 3 | Discovery Narrative | Narrative control document | Restricted internal control | `Item_3_Discovery_Narrative_LOCKED.md` | Internal master package only |
| 4 | Master Evidence Inventory v2 | Evidence inventory | Restricted / public summary only | `Item_4_Master_Evidence_Inventory_LOCKED.md` | Internal master package; public summary if separately approved |
| 5 | Discovery Chronology | Chronology document | Public-safe if reviewed | `Item_5_Discovery_Chronology_LOCKED.md` | 03_TECHNICAL_PUBLIC_BACKGROUND/ |
| 6 | Investigator Biography | Biography | Public | `Item_6_Investigator_Biography_LOCKED.txt` | 04_INVESTIGATOR_AND_ORGANIZATION/ |
| 7 | Controlled Quote Library | Quote control document | Restricted internal control; public derivative exists as Item 22 | `Item_7_Controlled_Quote_Library_LOCKED.md` | Internal master package only |
| 8 | Public Technical Backgrounder | Technical public explanation | Public | `Item_8_Public_Technical_Backgrounder_LOCKED.md` | 03_TECHNICAL_PUBLIC_BACKGROUND/ |
| 9 | Primary Press Release | Press release | Public | `Item_9_Primary_Press_Release_LOCKED.md` | 01_CORE_ANNOUNCEMENT/ |
| 10 | Executive Summary / Media Brief | Media brief | Public | `Item_10_Executive_Summary_Media_Brief_LOCKED.md` | 01_CORE_ANNOUNCEMENT/ |
| 11 | What Is the K-field? Fact Sheet | Fact sheet | Public | `Item_11_What_Is_the_K_field_Fact_Sheet_LOCKED.md` | 02_PUBLIC_EXPLANATION/ |
| 12 | FAQ Document | FAQ | Public | `Item_12_FAQ_Document_LOCKED.md` | 02_PUBLIC_EXPLANATION/ |
| 13 | Public Glossary | Glossary | Public | `Item_13_Public_Glossary_LOCKED.md` | 02_PUBLIC_EXPLANATION/ |
| 14 | Comparison Sheet | Comparison / positioning sheet | Public | `Item_14_Comparison_Sheet_LOCKED.md` | 02_PUBLIC_EXPLANATION/ |
| 15 | Press Release Image Set Specification | Visual production specification | Restricted / optional public reference | `Item_15_Press_Release_Image_Set_Specification_LOCKED.md` | Internal master or 06_VISUAL_ASSETS/ if useful |
| 16 | Primary Discovery Graphic Production Brief | Visual production brief | Restricted / optional public reference | `Item_16_Primary_Discovery_Graphic_Production_Brief_LOCKED.md` | Internal master or 06_VISUAL_ASSETS/ if useful |
| 17 | Technical Diagram Set Production Brief | Diagram production brief | Restricted / optional public reference | `Item_17_Technical_Diagram_Set_Production_Brief_LOCKED.md` | Internal master or 06_VISUAL_ASSETS/ if useful |
| 18 | Investigator Photo Assets Specification | Photo asset specification | Restricted / optional public reference | `Item_18_Investigator_Photo_Assets_Specification_LOCKED.md` | Internal master or 06_VISUAL_ASSETS/ if useful |
| 19 | Caption and Attribution Sheet | Caption / attribution sheet | Public | `Item_19_Caption_and_Attribution_Sheet_LOCKED.md` | 08_INDEX_AND_ATTRIBUTION/ |
| 20 | Optional Video / Animation Package | Motion asset specification | Restricted / optional public reference | `Item_20_Optional_Video_Animation_Package_LOCKED.md` | Internal master or 06_VISUAL_ASSETS/ if useful |
| 21 | Principal Investigator Profile | Investigator profile | Public | `Item_21_Principal_Investigator_Profile_LOCKED.md` | 04_INVESTIGATOR_AND_ORGANIZATION/ |
| 22 | Quote Sheet | Quote sheet | Public | `Item_22_Quote_Sheet_LOCKED.md` | 05_QUOTES_AND_MEDIA_QA/ |
| 23 | Organization Boilerplate | Organization boilerplate | Public | `Item_23_Organization_Boilerplate_LOCKED.md` | 04_INVESTIGATOR_AND_ORGANIZATION/ |
| 24 | Media Contact Sheet | Media operations sheet | Public version only after contact placeholders resolved | `Item_24_Media_Contact_Sheet_LOCKED.md` | 07_MEDIA_OPERATIONS/ |
| 25 | Embargo and Release Instructions | Release control document | Public version only after release details finalized | `Item_25_Embargo_and_Release_Instructions_LOCKED.md` | 07_MEDIA_OPERATIONS/ |
| 26 | Interview Preparation Sheet | Interview prep | Internal by default; public excerpt optional | `Item_26_Interview_Preparation_Sheet_LOCKED.md` | Internal master package or 07_MEDIA_OPERATIONS/ if public-approved |
| 27 | Journalist Q&A Brief | Journalist Q&A | Public | `Item_27_Journalist_QA_Brief_LOCKED.md` | 05_QUOTES_AND_MEDIA_QA/ |
| 28 | Press Email Pitch | Media outreach templates | Internal by default | `Item_28_Press_Email_Pitch_LOCKED.md` | Internal master package |
| 29 | Landing Page | Landing page specification and draft copy | Public after placeholders resolved | `Item_29_Landing_Page_LOCKED.md` | Online landing page / internal master |
| 30 | Downloadable Press Kit ZIP Specification | Press kit ZIP specification | Internal control | `Item_30_Downloadable_Press_Kit_ZIP_Specification_LOCKED.md` | Internal master package |
| 31 | Citation and Document Index | Document index | Public after placeholder/link review | `Item_31_Citation_and_Document_Index_DRAFT.md` | 08_INDEX_AND_ATTRIBUTION/ |


## Public ZIP inclusion recommendations

### Include by default after final placeholder review

- Item 8 — Public Technical Backgrounder
- Item 9 — Primary Press Release
- Item 10 — Executive Summary / Media Brief
- Item 11 — What Is the K-field? Fact Sheet
- Item 12 — FAQ Document
- Item 13 — Public Glossary
- Item 14 — Comparison Sheet
- Item 19 — Caption and Attribution Sheet
- Item 21 — Principal Investigator Profile
- Item 22 — Quote Sheet
- Item 23 — Organization Boilerplate
- Item 27 — Journalist Q&A Brief
- Item 31 — Citation and Document Index

### Include only after placeholder/contact/release review

- Item 24 — Media Contact Sheet
- Item 25 — Embargo and Release Instructions
- Item 29 — Landing Page copy or link reference

### Include only if specifically public-approved

- Item 5 — Discovery Chronology
- Item 15 — Press Release Image Set Specification
- Item 16 — Primary Discovery Graphic Production Brief
- Item 17 — Technical Diagram Set Production Brief
- Item 18 — Investigator Photo Assets Specification
- Item 20 — Optional Video / Animation Package
- Item 26 — Interview Preparation Sheet
- Item 28 — Press Email Pitch
- Item 30 — Downloadable Press Kit ZIP Specification

### Exclude from public ZIP by default

- Item 1 — Master Message Framework
- Item 2 — Controlled Glossary
- Item 3 — Discovery Narrative
- Item 4 — Master Evidence Inventory v2, unless a public summary is separately approved
- Item 7 — Controlled Quote Library, because Item 22 is the public derivative
- Internal audit files
- Source archives
- Draft files
- Reserved technical materials
- Private contact sheets or unresolved-contact documents

## Required public index fields

Each public index entry should include:

| Field | Requirement |
|---|---|
| Document title | Required |
| Document type | Required |
| Version / date | Required |
| Author / owner | Required |
| Short description | Required |
| Public / restricted status | Required |
| File name | Required |
| Location or link | Required |
| Notes | Optional but recommended |

## Public status definitions

| Status | Meaning |
|---|---|
| Public | Approved for public press-kit release after final release check |
| Public after placeholder review | Public-safe only after contact, URL, date, or release placeholders are resolved |
| Public-safe if reviewed | Likely public-safe but must be checked for reserved details |
| Restricted internal control | Not intended for public release; used to control package consistency |
| Internal by default | Operational document normally kept internal unless separately approved |
| Optional public reference | May be provided publicly if useful, but not required |
| Reserved technical | Not public; protected technical material |

## Citation guidance for public materials

When referencing documents on the landing page, in email pitches, or in media replies, use public document titles rather than internal item numbers.

Preferred public references:
- “Primary Press Release”
- “Executive Summary / Media Brief”
- “Public Technical Backgrounder”
- “FAQ”
- “Public Glossary”
- “Comparison Sheet”
- “Quote Sheet”
- “Caption and Attribution Sheet”
- “Journalist Q&A Brief”

Avoid exposing internal control labels such as:
- “Item 1”
- “Item 2”
- “Master Message Framework”
- “Internal audit”
- “Draft package”
- “Reserved technical archive”

## Link placeholder rules

Before public release, replace internal paths with final public links. Do not publish local filesystem paths, sandbox links, internal build directory names, or private storage URLs.

Public link fields should resolve to:
- Landing page
- Public press kit ZIP
- Public PDF/document URLs
- Approved image asset URLs
- Approved caption/attribution sheet
- Public media contact page or email

## Manifest relationship

This Item 31 index should be used together with the final public ZIP file manifest.

Difference:
- This document index explains the document set and public/restricted status.
- The file manifest lists every actual file included in the final ZIP.

Both should exist before final public release.

## Public README insertion

Recommended README language:

“For a complete inventory of public press materials, see the Citation and Document Index. The index identifies document titles, document types, public/restricted status, file names, and recommended locations. Reserved technical materials, internal control files, source archives, and draft files are not included in the public press kit.”

## Placeholder scan dependency

Before public release, scan every public index entry for:
- Placeholder URLs
- Local paths
- Sandbox paths
- Internal build paths
- Draft labels
- Unresolved contact fields
- Unresolved release dates
- Unresolved image links
- Unresolved media contact fields

Do not release the public index until those fields are resolved or intentionally omitted.

## Public release checklist

| Check | Pass condition |
|---|---|
| Document list completeness | Public press-kit documents are indexed. |
| Status clarity | Each document has public/restricted status. |
| Filename control | Recommended filenames are stable and public-safe. |
| Location control | Public links or final ZIP locations are provided. |
| No internal paths | No sandbox, local, or internal build paths appear in final public index. |
| Placeholder cleanup | Public-facing placeholders are resolved or removed. |
| Trade-secret boundary | Reserved technical materials are excluded. |
| Contact safety | Private contact details are not exposed. |
| ZIP dependency | Index aligns with Item 30 public ZIP specification. |
| Landing page fit | Index supports the approved landing page title and document links. |

## Do-not-release conditions

Do not release the public index if:
- It contains internal build paths.
- It contains unresolved public placeholders.
- It links to drafts.
- It links to reserved technical files.
- It lists internal control files as public documents.
- It exposes private contact information.
- It contradicts the locked public press materials.
- It implies full public release of proprietary derivation details.

## Quality checks before approval

| Check | Pass condition |
|---|---|
| Completeness | Index covers locked Items 1-30 and the draft Item 31. |
| Public utility | Journalists can identify what to read and where it belongs. |
| Boundary control | Internal and reserved materials are clearly separated from public materials. |
| Package consistency | Aligns with landing page, press kit ZIP specification, media contact sheet, release instructions, and caption sheet. |
| Release readiness | Provides rules for replacing internal paths with final public links. |
| Audit value | Supports final package audit and public ZIP manifest creation. |

---

Lock status: Approved by user and locked on 2026-07-01T17:57:19+00:00.
