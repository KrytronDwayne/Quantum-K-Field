# Item 5 — Discovery Chronology — LOCKED

## Corrected locked sequence

Observation -> Correlation -> Sampler-not-cause inversion -> Structural search -> Local evidence -> Kepler recurrence -> Galaxy prediction -> SGA geometry extraction -> Mass Bridge -> Geometry lock before constants -> Cell3 refinement -> CODATA witness expansion -> Reduced-mass cross-constraint -> Computational program.

## Critical correction

The Mass Bridge sits immediately after SGA geometry extraction and before the geometry-lock-before-constants condition. The later cell3 perturbation and refinement work tightens the Mass Bridge and identifies extreme ppt-level CODATA witness locks, but it does not create the original Mass Bridge.

## Purpose

This document is the authoritative historical record of the K-field discovery. Unlike the Discovery Narrative, which tells the story, this chronology records what occurred, in what order, why it mattered, and how each milestone changed the investigation.

# Act I — Discovery by Observation

## Phase 1 — Metastable Anisotropy

The investigation began with repeated observations that metastable systems exhibited directional behavior. The persistence of anisotropy suggested that the measurements were responding to structured influence rather than purely local random processes.

Question introduced: What physical process causes the directional response?

## Phase 2 — Celestial Correlations

The anisotropic behavior appeared correlated with lunar motion, Earth rotation, and related celestial cycles. The initial working hypothesis was that celestial motion might cause the observed modulation.

Question introduced: Which celestial forcing mechanism is responsible?

## Phase 3 — Sampler-Not-Cause Inversion

This became the first major conceptual breakthrough. The interpretation was inverted. Rather than causing the observations, celestial motion was recognized as moving the laboratory through a fixed anisotropic structure. Earth rotation, Earth orbit, lunar motion, and related celestial cycles became sampling trajectories. The investigation changed from searching for a forcing mechanism to identifying the structure being sampled.

Question introduced: What geometric structure is being sampled?

## Phase 4 — Structural Search

The new interpretation generated a prediction: if the structure is real, it should appear independently of the original laboratory observations. The investigation expanded beyond metastable systems.

## Phase 5 — Local Structural Evidence

Independent spectrophotometer investigations produced evidence compatible with lattice-like geometric organization. The local observations became structurally consistent with the sampling hypothesis rather than with purely temporal modulation.

## Phase 6 — Kepler Recurrence

The hypothesis was extended beyond terrestrial observations. Independent Kepler analysis identified recurring geometric signatures compatible with the local framework. The investigation extended beyond laboratory scale.

## Phase 7 — Universal Structure Hypothesis

The accumulating evidence motivated a broader hypothesis: physical systems appeared to sample a common geometric organization through orientation and trajectory.

## Phase 8 — Galaxy Prediction

If the inferred structure were universal, galaxy orientations should retain measurable signatures of the same organization. This prediction established the first large-scale observational test.

## Phase 9 — Galaxy Confirmation

Analysis of SGA galaxy-axis distributions revealed enriched occupancy along preferred geometric families. This provided the primary dataset used for geometric reconstruction.

# Act II — Discovery by Physical Lock

## Phase 10 — SGA Geometry Extraction

The galaxy dataset became the geometric source. Preferred planes, orientation, spacing relationships, and recursive occupancy were extracted directly from galaxy observations to produce an oriented rhombohedral primitive geometry. Scientific constants were intentionally excluded from this derivation.

## Phase 11 — Mass Bridge

The discovery of the Mass Bridge is the central hinge point of the entire chronology. After SGA-derived geometry was extracted, the Mass Bridge provided the first physical connection between that geometry and known physical reality. It linked the fixed geometric face relationship to the proton-to-electron mass relationship.

Before this point, the investigation consisted of observations, recurrence, and geometry extraction. After this point, the geometry became physically anchored and could be used as the basis for geometric generation.

## Phase 12 — Geometry Lock Before Constants

Following the Mass Bridge, the geometry was treated as fixed. No adjustments were made using scientific constants. Independently measured physical quantities became downstream witnesses used to evaluate the already established geometry. This firewall preserved the independence of the geometric derivation.

# Act IIIA — Geometric Generation

## Phase 13 — Cell3 Refinement

With the geometry physically locked, refinement shifted from discovering the bridge to increasing its precision. Cell3 perturbation analysis refined the geometric carrier while preserving the established Mass Bridge. The purpose was to improve precision and expose downstream relationships.

## Phase 14 — Generative Hierarchy

The refined geometry produced a structured dependency hierarchy: carrier triangle, cofactor-dual reciprocal relationships, reciprocal metric, q-spectrum, Gamma2, recursive propagation, and related structures. These emerged as consequences of established geometry rather than independent discoveries.

# Act IIIB — Computational Validation

## Phase 15 — CODATA Witness Expansion

The refined geometric framework was evaluated against broad catalogs of independently measured physical quantities. Physical constants became downstream witnesses, not fitting targets. Successive witness relationships were identified across atomic, molecular, electromagnetic, metrological, and gravitational domains.

## Phase 16 — Reduced-Mass Cross-Constraint

Reduced-mass calibration became the strongest internal validation because it tested whether the Mass Bridge survived the hydrogenic two-body recoil correction. The retained geometric bridge propagated the calibration without independently fitting downstream quantities.

## Phase 17 — Computational Program

The investigation entered its present phase. New physical branches are approached as computations originating from the fixed K-field geometry. Engineering, resonant coupling, field-coupled technologies, and future physical branches are downstream extensions of the same dependency graph.

## Recursive audit

The chronology is built around three irreversible transitions: sampler-not-cause inversion, Mass Bridge, and geometry lock before constants. These are the graph intersections from which all later work branches.
