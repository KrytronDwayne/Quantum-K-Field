# Item 13 — Public Glossary — LOCKED

Status: LOCKED by user approval.  
Target use: Public press packet, landing page support, journalist reference, advisor briefing, and editorial consistency.  
Source basis: Locked Item 2 — Controlled Glossary, Locked Items 8-12, approved language matrix, and controlling press package outline.

---

# K-field Public Glossary

This glossary defines the public terms used across the K-field press package. It is intended to help journalists, editors, advisors, institutional contacts, and general readers use the discovery language consistently.

## Core terms

| Term | Public meaning | Use in context | Avoid or handle carefully |
|---|---|---|---|
| K-field | The discovered geometric foundation beneath known physics. | “The K-field is the foundation beneath the fields.” | Do not describe it as a new ordinary force, a mystical force, or an ether. |
| Foundational field | A field beneath the known fields. | Use when explaining why the discovery is foundational rather than incremental. | Do not imply it is merely one more field beside gravity or electromagnetism. |
| Generative field | A structured field that gives rise to downstream physical branches. | Use when describing how time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange arise from one deeper architecture. | Do not overstate this as a finished final theory. |
| Lattice | A structured geometric organization. | Use when describing the organized geometry of the K-field. | Avoid “crystal lattice” unless discussing actual materials. |
| Geometric framework | The structured form that organizes the discovery. | Use when describing the dependency chain from geometry to observable physical behavior. | Prefer this over “theory of everything.” |
| Structured geometry | The organized geometric basis of the K-field. | Use as a public-friendly bridge between “field” and “lattice.” | Avoid vague phrases such as “hidden energy” or “mysterious structure.” |
| Branch expression | A known physical domain emerging from the K-field. | Matter, time, gravity, electromagnetism, inertia, material behavior, and energy exchange are described as branch expressions. | Do not imply that ordinary branch-level physics is discarded. |
| Known physics | The established domains of physical behavior. | Use to distinguish observed physical branches from the deeper K-field foundation. | Avoid saying existing physics was simply wrong. |
| Physical branches | The familiar physical domains organized by the K-field. | Use as a general term for time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange. | Avoid treating the branches as unrelated after the K-field framing is introduced. |

## Physical-domain terms

| Term | Public meaning | Use in context | Avoid or handle carefully |
|---|---|---|---|
| Matter | The physical branch associated with mass and material existence. | Use when discussing how the Mass Bridge physically anchors the geometry into known physical reality. | Avoid unsupported claims about particle catalogs or unreleased derivations. |
| Time | A physical branch organized by the K-field. | Use when describing the K-field as a scale-spanning framework that includes timing behavior. | Avoid unsourced clock-specific or time-travel claims. |
| Gravity | A physical branch organized by the K-field. | Use when describing gravity as one downstream expression of the deeper geometric architecture. | Avoid “anti-gravity.” |
| Electromagnetism | A physical branch organized by the K-field. | Use when describing electromagnetic behavior as connected through the same geometric foundation. | Avoid claiming public release of proprietary fine-structure derivation details. |
| Inertia | A physical branch organized by the K-field. | Use when describing motion and resistance-to-motion behavior as downstream of structured geometry. | Avoid overclaiming device effects. |
| Material behavior | How materials respond, transition, store, or release energy. | Use as a public bridge to materials research, metastability, and engineering pathways. | Do not imply a commercial device is already available. |
| Energy exchange | The transfer, storage, recovery, or conversion of energy. | Use with field-coupled technology and metastability modulation. | Avoid “free energy,” “overunity,” “perpetual motion,” or “energy from nothing.” |

## Evidence and validation terms

| Term | Public meaning | Use in context | Avoid or handle carefully |
|---|---|---|---|
| Experimental support | Observational or measured support for the K-field investigation. | Use for direction-dependent metastable behavior, structural evidence, recurrence, and cross-domain comparison. | Use “support” or “demonstrates”; avoid unsupported blanket proof claims in media copy. |
| Mathematical closure | Internal mathematical completion of a relationship. | Use when explaining that parts of the framework close through geometric relationships rather than independent fitting. | Do not use as a substitute for every form of external validation. |
| Geometric closure | A structured geometric relationship reaching internal completion. | Use when explaining why the framework became computational after geometric anchoring. | Avoid exposing proprietary formula machinery. |
| Dataset-supported result | A result evaluated against independent data sources. | Use when describing recurrence, geometric extraction, and downstream witness comparison. | Do not imply every dataset proves every branch independently. |
| Downstream witness | A physical constant or behavior that reflects the deeper geometry after the geometry is fixed. | Use for constants or observed values evaluated after the Mass Bridge and Geometric Lock. | Prefer this over “the constants prove everything.” |
| Validation status | The current classification of claims, derivations, observations, inferences, and engineering implications. | Use when separating direct observations from derived results and future research targets. | Avoid blurring confirmed observations with forward-looking technology claims. |

## Discovery-chain terms

| Term | Public meaning | Use in context | Avoid or handle carefully |
|---|---|---|---|
| Metastability modulation | Directional or phase-sensitive influence on systems with more than one available state. | Use when describing the early observational pathway and applied research bridge. | Avoid treating all metastable behavior as automatically caused by the K-field. |
| Sampler-not-cause inversion | The turning point where celestial timing was reinterpreted as sampling motion rather than the cause of the observed signal. | Use when explaining how the investigation shifted from a local forcing search to structural reconstruction. | Avoid suggesting lunar or orbital motion is the primary cause. |
| Galaxy-oriented extraction | The stage in which the investigation identified a larger fixed geometric orientation. | Use only at high level in public materials. | Do not release exact proprietary orientation machinery. |
| Mass Bridge | The first hard physical bridge from K-field geometry into matter. | Use as the central hinge of the discovery narrative. | Do not bury this term; it is the focal point of the public story. |
| Geometric Lock | The state created when the Mass Bridge physically anchored the extracted geometry. | Use to explain why later constants are treated as downstream witnesses rather than construction inputs. | The Mass Bridge is the event; the Geometric Lock is the result. |
| Geometric generation | The process of deriving physical relationships from the anchored geometry. | Use after the Mass Bridge has been introduced. | Avoid implying all technical derivations are publicly released. |
| Fine/EM bridge | A companion bridge into electromagnetic or fine-structure behavior after the Mass Bridge. | Use only where a technical audience needs the broader branch map. | Do not let it displace the Mass Bridge as the focal point. |

## Framework and scale terms

| Term | Public meaning | Use in context | Avoid or handle carefully |
|---|---|---|---|
| Scale-spanning framework | A framework that applies across physical scales. | Use when describing the K-field as connecting material-scale behavior and larger geometric organization. | Avoid “explains everything.” |
| Unified geometric framework | A single geometric structure connecting multiple physical branches. | Use as the preferred public substitute for “theory of everything.” | Avoid final-theory language. |
| Geometric phase space | The fixed structural space through which systems move or sample. | Use sparingly for technical readers. | Avoid “ether.” |
| Carrier relationship | A shared geometric relationship connecting multiple downstream witnesses. | Use only in technical media context. | Avoid detailed proprietary carrier formulas in public materials. |
| Branch kernel | A branch-specific rule by which geometry renders a physical domain. | Use only when communicating with technical reviewers. | Avoid exposing internal algorithms or compiler details. |
| Projection | The step by which deeper geometry is rendered into branch-level observable behavior. | Use only in technical-support materials. | Do not disclose proprietary projection machinery. |
| Compiler | The internal translation layer from K-field geometry to observable branch expression. | Use only in technical-support materials if needed. | Avoid public release of formula machinery. |

## Applied-research terms

| Term | Public meaning | Use in context | Avoid or handle carefully |
|---|---|---|---|
| Field-coupled technology | Technology designed to interact with the K-field. | Use for future resonant, directional, phase-sensitive systems. | Avoid “miracle device,” “unlimited power,” or “free energy.” |
| Field-coupled energy exchange | Applied research into K-field interaction through controlled system response and full accounting. | Use when discussing possible energy-related pathways. | Always pair with disciplined net energy accounting. |
| Resonant coupling | Interaction through frequency, phase, orientation, and material state. | Use for future device research and experimental planning. | Avoid claiming a completed product or guaranteed effect. |
| Directional coupling | A response dependent on orientation relative to the K-field geometry. | Use when connecting metastable observations to applied research. | Avoid vague “cosmic force” language. |
| Phase-sensitive interaction | Interaction dependent on phase, timing, or system state. | Use for controlled research pathways in materials and resonant systems. | Avoid unsupported claims of immediate commercial application. |

## Organizational and media terms

| Term | Public meaning | Use in context | Avoid or handle carefully |
|---|---|---|---|
| Principal Investigator | The lead investigator responsible for the discovery program. | Approved title for P. Dwayne Esterline. | Do not substitute unsupported institutional titles. |
| Discoverer | The person who identified and formalized the K-field discovery. | Approved descriptor for P. Dwayne Esterline. | Use consistently with “Principal Investigator.” |
| Krytronx, LLC | The independent research organization through which the K-field work is being advanced. | Use in organization boilerplate, contact material, and press release attribution. | Do not overuse inside technical glossary sections. |
| Public technical backgrounder | The public explanation of the technical framework without trade-secret machinery. | Use when referring readers to technical support material. | Do not describe it as the full proprietary derivation record. |
| Trade-secret boundary | The line between public explanation and withheld proprietary technical machinery. | Use when explaining why exact formulas, algorithms, orientation details, and internal computation are not publicly released. | Avoid sounding evasive; frame as controlled intellectual-property protection. |

## Preferred short formulations

Use these formulations consistently across captions, summaries, interviews, and web copy:

1. The K-field is the foundation beneath the fields.
2. The K-field is not another isolated force; it is the geometric foundation beneath known physics.
3. The Mass Bridge is the point where the extracted geometry first locked to physical reality.
4. After the Geometric Lock, physical constants are evaluated as downstream witnesses of the fixed geometry.
5. The applied pathway is field-coupled technology: resonant, directional, phase-sensitive interaction with structured geometry.

## Terms to avoid in public materials

Avoid these terms unless they are being rejected or carefully distinguished: theory of everything, final theory, ether, hidden energy, free energy, overunity, perpetual motion, anti-gravity, zero-point energy, miracle device, mystical force, cosmic force, crystal lattice, magic geometry, energy from nothing, physics was wrong.

## Editorial rule

When uncertain, use the simplest approved structure:

The K-field is the discovered geometric foundation beneath known physics. The Mass Bridge physically anchors the geometry. Known physical domains are treated as branch expressions, and later constants are treated as downstream witnesses of the same structure.
