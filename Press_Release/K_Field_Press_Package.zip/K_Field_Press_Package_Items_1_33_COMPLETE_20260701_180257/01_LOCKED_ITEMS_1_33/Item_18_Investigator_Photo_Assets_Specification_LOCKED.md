# Item 18 — Investigator Photo Assets Specification — LOCKED

Status: LOCKED by user approval.  
Target use: Press kit downloads, author/investigator profile, website landing page, media articles, institutional outreach, interview scheduling pages, and presentation biography slides.  
Source basis: Locked Items 1-17, especially the locked investigator biography, primary press release, executive summary, public glossary, image set specification, primary discovery graphic brief, and technical diagram set brief.  
Public boundary: This specification controls portrait, profile, and environmental photo assets only. It does not disclose proprietary geometry, technical derivations, private locations, unreleased devices, private documents, or trade-secret research materials.

---

# Investigator Photo Assets Specification

## Purpose

The investigator photo assets should give journalists and web editors usable, professional images of P. Dwayne Esterline for coverage of the K-field discovery. The image set should support credibility, continuity, and reproducibility across press articles, institutional outreach, and online publication.

The photos should present the investigator as the principal investigator and discoverer of the K-field, with a restrained technical-business tone. The visual impression should be serious, disciplined, independent, and research-oriented. Avoid theatrical, mystical, promotional, or inventor-gadget aesthetics.

## Controlling visual statement

The investigator photo set should visually support this sentence:

“P. Dwayne Esterline is the independent investigator and principal of Krytronx, LLC, presenting the K-field discovery through a disciplined public press package.”

The photos should support the discovery announcement without competing with the K-field visuals or implying commercial product release.

## Required photo set

| Asset ID | Filename | Aspect ratio | Primary use | Status |
|---|---|---:|---|---|
| PHOTO-01 | p_dwayne_esterline_press_headshot_square.jpg | 1:1 | Media profile, press kit, social preview | Pending production |
| PHOTO-02 | p_dwayne_esterline_press_headshot_vertical.jpg | 4:5 or 3:4 | Article author image, institutional page | Pending production |
| PHOTO-03 | p_dwayne_esterline_research_portrait_landscape.jpg | 16:9 | Website feature, article lead support | Pending production |
| PHOTO-04 | p_dwayne_esterline_neutral_portrait.jpg | 3:2 or 4:5 | General media use | Pending production |
| PHOTO-05 | p_dwayne_esterline_interview_thumbnail.jpg | 16:9 | Video interview, podcast, press scheduling | Pending production |

The set may be produced from one professional portrait session if the source image quality supports all crops. If only one image is available, prioritize PHOTO-01 and PHOTO-02.

## Visual style

Use a clean, modern, professional press portrait style. The subject should be well-lit, sharp, natural, and approachable without looking casual or promotional. Clothing should be business casual or professional; solid colors or restrained patterns are preferred.

Preferred style:
- Neutral technical-business portrait
- Controlled lighting
- Clean background
- Natural expression
- No heavy theatrical contrast
- No exaggerated science-fiction styling
- No prop-driven inventor pose

Avoid:
- Lab-coat costume unless authentic and contextually appropriate
- Holding devices, coils, prototypes, notebooks, or unreleased technical materials
- Equations or proprietary diagrams visible in the background
- Dramatic cosmic backgrounds
- Mystical, occult, or “genius inventor” visual clichés
- Overprocessed HDR effects
- AI-looking facial artifacts
- Distracting brand logos or political/religious symbols

## Background guidance

Approved background options:
- Plain neutral background
- Soft slate or dark-blue technical-business backdrop
- Office or research workspace with no readable proprietary materials
- Abstract blurred background using the approved slate/cyan/orange visual system
- Clean wall with controlled shadow and depth

Avoid background elements:
- Whiteboards with formulas
- Exact diagrams or derivations
- Private documents
- Unreleased device imagery
- Messy workspaces
- Domestic clutter
- Strongly partisan, religious, or cultural symbols
- Stock-photo laboratory clichés

## Color and typography alignment

Photo assets should visually align with the locked press-package visual system, but portraits should not be forced into a synthetic color grade.

Preferred visual alignment:
- Slate/dark-blue background or wardrobe compatibility with `#0F172A`
- Subtle cyan-blue environmental accent compatible with `#0EA5E9`
- Very restrained warm accent compatible with `#F97316` only if natural and not distracting
- No heavy purple, rainbow, neon green, or red/orange dominance

Text should generally not be embedded inside portrait images. If a labeled version is needed later, use the locked Item 16 typography system:
- Inter SemiBold for name
- Inter Regular or Medium for title
- Aptos, Arial, Helvetica, or Liberation Sans as fallbacks

## Recommended title and identification text

Use the following caption and identification conventions outside the image file, not embedded in the main portrait unless a designed card is explicitly produced later.

Preferred name line:
“P. Dwayne Esterline”

Preferred role line:
“Principal, Krytronx, LLC”

Preferred discovery line:
“Discoverer of the K-field”

Optional full role line:
“P. Dwayne Esterline, Principal of Krytronx, LLC and discoverer of the K-field.”

## Caption controls

Short caption:

“P. Dwayne Esterline, Principal of Krytronx, LLC and discoverer of the K-field.”

Long caption:

“P. Dwayne Esterline is the owner and Principal of Krytronx, LLC, an independent research firm focused on further development of the K-field discovery. The K-field is presented in the press package as a discovered geometric foundation beneath known physics, physically anchored by the Mass Bridge.”

Credit line:

“Photo credit: Krytronx, LLC / K-field Discovery Press Materials.”

Usage-rights statement:

“Approved for use in coverage of the K-field discovery announcement. Do not alter in ways that imply commercial product endorsement, unreleased technical disclosure, institutional affiliation not stated in the approved materials, or claims beyond the approved press package.”

## Alt text

Recommended alt text:

“Portrait of P. Dwayne Esterline, Principal of Krytronx, LLC and discoverer of the K-field.”

Short alt text:

“P. Dwayne Esterline portrait.”

## Cropping rules

| Asset | Crop guidance |
|---|---|
| Square headshot | Center face and shoulders; leave enough margin for circular platform crops. |
| Vertical portrait | Head and upper torso; preserve natural posture and professional context. |
| Landscape research portrait | Subject placed left or right with clean negative space for headline or caption. |
| Neutral portrait | Flexible crop with minimal background and no embedded text. |
| Interview thumbnail | Use 16:9 crop with subject clearly visible at small size. |

Do not crop too tightly at the top of the head or chin. Leave safe margins for publisher templates, circular crops, and social media preview overlays.

## Image quality requirements

| Requirement | Minimum |
|---|---|
| Resolution | Long edge at least 3000 px for master images where possible |
| Web export | Long edge 1600-2400 px |
| Color | sRGB for web; retain higher-quality master if available |
| File type | JPG for portraits; PNG only if composited with graphic elements |
| Sharpness | Eyes and face in focus |
| Noise/artifacts | No visible AI artifacts, compression blocks, haloing, or over-smoothing |
| Metadata | Retain basic credit/version metadata if workflow supports it |

## File export requirements

| Output | Filename | Format | Minimum target |
|---|---|---|---|
| Square headshot | p_dwayne_esterline_press_headshot_square.jpg | JPG | 2000 × 2000 px |
| Vertical headshot | p_dwayne_esterline_press_headshot_vertical.jpg | JPG | 1600 × 2000 px or larger |
| Landscape research portrait | p_dwayne_esterline_research_portrait_landscape.jpg | JPG | 2400 × 1350 px |
| Neutral portrait | p_dwayne_esterline_neutral_portrait.jpg | JPG | Long edge at least 2000 px |
| Interview thumbnail | p_dwayne_esterline_interview_thumbnail.jpg | JPG | 1920 × 1080 px |
| Internal master | p_dwayne_esterline_press_portrait_master.* | RAW, TIFF, or high-quality JPG | Retain internally |

## Selection checklist

Before approval, the selected photo set should pass these checks:

| Check | Pass condition |
|---|---|
| Professional credibility | Looks suitable for science, technology, and business press. |
| Message alignment | Supports the investigator role without distracting from the K-field discovery. |
| Visual neutrality | Avoids mystical, sensational, gadget-driven, or fringe-coded cues. |
| Trade-secret boundary | No proprietary formulas, diagrams, devices, files, screens, or private materials visible. |
| Publisher utility | Works in square, vertical, and landscape crops. |
| Reproduction quality | Looks clean in web, social, PDF, and print contexts. |
| Caption consistency | Uses the approved name, role, credit line, and rights statement. |
| Brand consistency | Compatible with the locked slate/cyan/orange visual system without looking artificial. |

## Optional designed profile card

A designed profile card may be produced later if needed, but it is not required for Item 18.

If produced, it should use:
- Background: `#0F172A`
- Name: Inter SemiBold
- Role: Inter Regular or Medium
- Accent line or frame: `#0EA5E9`
- Minimal Mass Bridge or K-field mark only if already approved
- No formulas, witness numbers, or protected diagrams

Suggested profile-card text:

“P. Dwayne Esterline  
Principal, Krytronx, LLC  
Discoverer of the K-field”

## Editorial control rule

The investigator photo assets should establish credibility and identity. They should not attempt to visually prove the discovery, display technical evidence, imply institutional endorsement, or show unreleased devices. The safe hierarchy is: person, role, organization, discovery association.

---

Lock status: Approved by user and locked on 2026-07-01T17:24:42+00:00.
