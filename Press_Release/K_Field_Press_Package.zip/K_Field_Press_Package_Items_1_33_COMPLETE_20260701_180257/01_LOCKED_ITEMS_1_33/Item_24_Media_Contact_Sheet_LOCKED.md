# Item 24 — Media Contact Sheet — LOCKED

Status: LOCKED by user approval.  
Target use: Press release, press-kit cover page, downloadable media packet, website press page, journalist routing, interview scheduling, embargo coordination, image-use inquiries, and institutional outreach.  
Source basis: Locked Items 1-23, especially the primary press release, executive summary, FAQ, Principal Investigator Profile, Organization Boilerplate, Caption and Attribution Sheet, Quote Sheet, and visual/media asset specifications.  
Public boundary: This sheet controls media contact structure and routing language only. It does not disclose private contact details, proprietary technical material, exact derivations, unpublished evidence, trade-secret research details, or personal information not approved for public release.

---

# Media Contact Sheet

## Purpose

The Media Contact Sheet provides a controlled structure for routing press inquiries, interview requests, image-use questions, document requests, and institutional correspondence related to the K-field discovery announcement.

This sheet uses placeholders until final contact details are verified. No personal email, phone number, physical address, or private contact information should be added unless expressly approved for public release.

## Primary media contact block

Media Contact  
Krytronx, LLC  
[Contact Name Placeholder]  
[Role / Media Relations Placeholder]  
[Email Placeholder]  
[Phone Placeholder]  
[Website Placeholder]  
[Press Kit Download Link Placeholder]

Use only verified public-facing contact information. If a public phone number is not intended, omit the phone field rather than using a private number.

## Short media contact block

Media inquiries: [Email Placeholder]  
Press materials: [Press Kit Download Link Placeholder]  
Website: [Website Placeholder]

## Press release contact footer

Media Contact: [Contact Name Placeholder], Krytronx, LLC  
Email: [Email Placeholder]  
Phone: [Phone Placeholder]  
Press Kit: [Press Kit Download Link Placeholder]

If no public phone number is approved, use:

Media Contact: [Contact Name Placeholder], Krytronx, LLC  
Email: [Email Placeholder]  
Press Kit: [Press Kit Download Link Placeholder]

## Inquiry routing categories

| Inquiry type | Routing target | Response goal |
|---|---|---|
| General media inquiry | Media contact placeholder | Provide press materials and route questions |
| Interview request | Media contact placeholder | Schedule or decline based on availability |
| Technical clarification | Technical review / PI routing placeholder | Provide approved public materials only |
| Image-use request | Media contact placeholder | Provide approved assets and attribution terms |
| Quote verification | Media contact placeholder | Confirm approved quotes and attribution |
| Institutional inquiry | Institutional outreach placeholder | Route to PI or approved representative |
| Legal / rights inquiry | Rights contact placeholder | Confirm usage rights or request review |
| Unverified technical claim inquiry | Media contact placeholder | Respond only with approved public language |

## Approved response language

### General press inquiry

“Thank you for your inquiry regarding the K-field discovery announcement. The approved press materials include the primary press release, executive summary, technical backgrounder, FAQ, glossary, comparison sheet, visual asset specifications, quote sheet, and organization boilerplate. We can provide the current press kit and route specific questions for review.”

### Interview request

“Thank you for your interview request regarding the K-field discovery. Please provide the proposed format, publication or program name, target date, estimated length, topic focus, and whether the interview will be live, recorded, written, or edited. We will review the request and respond with availability or next steps.”

### Technical clarification request

“The public press package explains the K-field discovery, its Mass Bridge focal point, and its foundation-to-branch hierarchy. Exact derivation pathways, protected geometry, witness construction details, and internal computational machinery remain reserved as proprietary technical material.”

### Image-use request

“Approved visual assets may be used for editorial coverage of the K-field discovery announcement when used with the approved caption, credit line, and usage statement. Images should not be altered in ways that imply a completed commercial product, released proprietary derivation, anti-gravity device, free-energy claim, metaphysical interpretation, unsupported institutional endorsement, or exact disclosure of protected geometry.”

### Quote verification request

“Please use quotes only as listed in the approved Quote Sheet, attributed to P. Dwayne Esterline, Principal of Krytronx, LLC and discoverer of the K-field, unless a different attribution has been explicitly approved.”

## Contact data fields to verify before public release

| Field | Status | Notes |
|---|---|---|
| Public contact name | Placeholder | Must be approved before publication |
| Public contact role | Placeholder | Use “Media Contact” if no named role is preferred |
| Public email address | Placeholder | Prefer dedicated media email over private personal email |
| Public phone number | Placeholder / optional | Omit if not intended for public release |
| Public website URL | Placeholder | Use exact approved URL only |
| Press kit download URL | Placeholder | Use exact final package URL only |
| Mailing address | Omit unless approved | Avoid exposing private address |
| Time zone | America/Chicago unless otherwise specified | Useful for interview scheduling |
| Response window | Placeholder | Optional; avoid promising unrealistic response times |

## Interview scheduling fields

For interview requests, collect:

| Field | Requirement |
|---|---|
| Requesting journalist / outlet | Required |
| Contact email | Required |
| Contact phone | Optional |
| Format | Live, recorded, written, podcast, video, panel, or other |
| Proposed date / time | Required if scheduling requested |
| Time zone | Required |
| Expected duration | Required |
| Topic focus | Required |
| Technical depth | Public overview, technical backgrounder, or expert discussion |
| Publication date | Optional but preferred |
| Embargo requirements | Required if applicable |
| Recording / editing policy | Required if applicable |

## Interview-routing note

Interview requests should be reviewed for alignment with the approved press package. Questions involving proprietary derivation details, exact geometry, witness tables, unpublished technical machinery, or unreleased device claims should be redirected to the approved public materials.

## Rights and image-use routing

All image-use requests should be checked against Item 19: Caption and Attribution Sheet. Use the approved credit lines:

Graphics and diagrams:
“Image credit: Krytronx, LLC / K-field Discovery Press Materials.”

Portraits:
“Photo credit: Krytronx, LLC / K-field Discovery Press Materials.”

Video:
“Video credit: Krytronx, LLC / K-field Discovery Press Materials.”

Default usage statement:
“Approved for use in coverage of the K-field discovery announcement. Do not alter in ways that imply a completed commercial product, released proprietary derivation, anti-gravity device, free-energy claim, metaphysical interpretation, institutional endorsement not stated in the approved materials, or exact disclosure of protected geometry.”

## Public technical boundary

Media contacts should use this approved boundary statement when needed:

“The public materials explain the K-field discovery, its hierarchy, and the Mass Bridge focal point while preserving exact derivation pathways and proprietary technical machinery as reserved technical material.”

Do not say:
- “The proof is secret.”
- “The evidence cannot be shared.”
- “The details are hidden.”
- “Everything has already been fully disclosed.”
- “All technical derivations are available publicly.”

Preferred phrasing:
- “Reserved proprietary derivation details.”
- “Public-facing explanation materials.”
- “Approved technical backgrounder.”
- “Mass Bridge focal point.”
- “Foundation-to-branch hierarchy.”

## Media contact dos and don’ts

| Do | Do not |
|---|---|
| Use verified public contact details only | Use private contact details without approval |
| Route technical questions to approved materials | Improvise technical derivations |
| Provide approved captions and credits | Let publishers invent unsupported image captions |
| Confirm quote wording from Item 22 | Modify quotes casually |
| Preserve the trade-secret boundary | Say evidence is unavailable or hidden |
| Use neutral, professional language | Use sensational, combative, or mystical framing |
| Ask for interview format and topic focus | Accept open-ended live technical questioning without prep |
| Keep media records organized | Route all inquiries informally through personal channels |

## Public-facing contact safety rule

No physical address, private phone number, private email account, personal residence detail, private schedule detail, or private location should be included in the public press kit unless explicitly approved.

If no final contact details are available, the Media Contact Sheet should remain internal until a public contact channel is created.

## Recommended media email structure

Preferred:
media@[approved-domain-placeholder]

Acceptable:
press@[approved-domain-placeholder]

Avoid:
- Personal home email
- Unbranded generic email unless necessary
- Email addresses that imply a larger staff or department than exists
- Email addresses tied to private accounts or unrelated businesses

## Website press page contact block

Recommended layout:

Press Inquiries  
For media questions, interview requests, approved visual assets, or press materials related to the K-field discovery, contact:

[Contact Name Placeholder]  
Krytronx, LLC  
[Email Placeholder]  
[Website Placeholder]  
[Press Kit Download Link Placeholder]

## Internal routing checklist

Before responding to an inquiry, identify:

1. Who is asking?
2. What outlet or institution do they represent?
3. What exactly are they requesting?
4. Is the request public, technical, legal, institutional, or visual?
5. Does the request involve proprietary details?
6. Is there an approved document that answers the request?
7. Does the response require PI review?
8. Should the inquiry be logged for follow-up?

## Approval checklist before public release

| Check | Pass condition |
|---|---|
| Contact accuracy | All public contact details are verified. |
| Privacy protection | No private contact information is exposed. |
| Routing clarity | Inquiry types have clear routing instructions. |
| Technical boundary | Proprietary details remain reserved. |
| Quote control | Quote verification routes back to Item 22. |
| Image rights | Image-use requests route back to Item 19. |
| Press release fit | Footer contact block works with the locked press release. |
| Website fit | Press-page block works for online publication. |
| No invented details | No email, phone, address, URL, or staff role is invented. |

---

Lock status: Approved by user and locked on 2026-07-01T17:39:11+00:00.
