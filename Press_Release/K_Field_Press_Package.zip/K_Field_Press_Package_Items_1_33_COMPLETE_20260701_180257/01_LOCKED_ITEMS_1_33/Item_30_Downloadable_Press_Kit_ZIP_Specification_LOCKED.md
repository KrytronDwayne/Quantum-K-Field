# Item 30 — Downloadable Press Kit ZIP Specification — LOCKED

Status: LOCKED by user approval.  
Target use: Final public press-kit download bundle, website landing page download, journalist resource package, institutional reference packet, and controlled media distribution archive.  
Source basis: Locked Items 1-29, especially the primary press release, executive summary, public technical backgrounder, fact sheet, FAQ, public glossary, comparison sheet, quote sheet, organization boilerplate, caption and attribution sheet, media contact sheet, embargo and release instructions, landing page, and all visual/media specifications.  
Public boundary: This specification controls the public downloadable press-kit ZIP. It does not authorize release of proprietary geometry, exact derivation pathways, orientation data, witness tables, internal branch-generation rules, projection/compiler machinery, unreleased devices, private contact details, internal drafts, or trade-secret technical material.

---

# Downloadable Press Kit ZIP Specification

## Purpose

The downloadable press kit ZIP should give journalists, editors, institutional contacts, podcast hosts, and public reviewers a single clean package containing the approved public K-field discovery materials.

The ZIP should be organized, publication-ready, easy to navigate, and free of internal drafts, private notes, unresolved placeholders, reserved technical files, or source archives not approved for public release.

## Controlling rule

Only locked and public-approved materials should be included in the final downloadable press kit ZIP.

Do not include:
- Internal drafts
- Source archives
- Private contact details
- Proprietary derivation files
- Protected geometry
- Exact orientation data
- Witness tables not approved for release
- Unreleased device or engineering materials
- Working notes
- Hidden metadata containing private comments
- Any file with unresolved public placeholders

## Recommended public ZIP filename

`K_Field_Discovery_Press_Kit_PUBLIC_vYYYYMMDD.zip`

Alternative filename:

`K-field_Discovery_Announcement_Press_Kit_vYYYYMMDD.zip`

Do not use filenames implying anti-gravity, free energy, final theory, product launch, or complete public technical disclosure.

## Required root folder

Inside the ZIP, use one root folder:

`K_Field_Discovery_Press_Kit_PUBLIC_vYYYYMMDD/`

All files should be contained inside this root folder rather than placed loose at ZIP root.

## Recommended folder structure

```text
K_Field_Discovery_Press_Kit_PUBLIC_vYYYYMMDD/
  00_README/
  01_CORE_ANNOUNCEMENT/
  02_PUBLIC_EXPLANATION/
  03_TECHNICAL_PUBLIC_BACKGROUND/
  04_INVESTIGATOR_AND_ORGANIZATION/
  05_QUOTES_AND_MEDIA_QA/
  06_VISUAL_ASSETS/
  07_MEDIA_OPERATIONS/
  08_INDEX_AND_ATTRIBUTION/
```

## Required README

Filename:

`00_README/README_PRESS_KIT.md`

Required contents:
- Press kit title
- Release status
- Release date/time
- Contact information
- Short K-field description
- Contents summary
- Public/reserved boundary statement
- Image usage note
- Quote usage note
- Version date
- Document index link

Recommended README opening:

“This press kit provides public materials for the K-field discovery announcement by P. Dwayne Esterline, Principal of Krytronx, LLC. The K-field is presented as a discovered geometric foundation beneath known physics, physically anchored by the Mass Bridge. Exact derivation pathways, protected geometry, witness construction details, and internal computational machinery remain reserved as proprietary technical material.”

## Required public contents

### 01_CORE_ANNOUNCEMENT

| File | Source item | Required |
|---|---:|---|
| Primary Press Release | Item 9 | Yes |
| Executive Summary / Media Brief | Item 10 | Yes |
| Short Announcement Paragraph, if separated later | Item 1 / Item 9 / Landing page source | Optional |
| Embargo and Release Instructions | Item 25 | Public version only if release status is finalized |

### 02_PUBLIC_EXPLANATION

| File | Source item | Required |
|---|---:|---|
| What Is the K-field? Fact Sheet | Item 11 | Yes |
| FAQ Document | Item 12 | Yes |
| Public Glossary | Item 13 | Yes |
| Comparison Sheet | Item 14 | Yes |

### 03_TECHNICAL_PUBLIC_BACKGROUND

| File | Source item | Required |
|---|---:|---|
| Public Technical Backgrounder | Item 8 | Yes |
| Discovery Chronology | Item 5 | Yes |
| Master Evidence Inventory public/executive summary | Item 4 if public-safe version is available | Optional / review required |
| Formula and theorem appendix | Not approved for public release unless separately created | Exclude by default |
| Validation status sheet | Not yet created as final public item | Exclude until approved |

### 04_INVESTIGATOR_AND_ORGANIZATION

| File | Source item | Required |
|---|---:|---|
| Investigator Biography | Item 6 | Yes |
| Principal Investigator Profile | Item 21 | Yes |
| Organization Boilerplate | Item 23 | Yes |
| Investigator Photo Assets | Item 18 / final images when available | Optional until final image files exist |

### 05_QUOTES_AND_MEDIA_QA

| File | Source item | Required |
|---|---:|---|
| Quote Sheet | Item 22 | Yes |
| Journalist Q&A Brief | Item 27 | Yes |
| Interview Preparation Sheet | Item 26 | Internal or public version decision required |
| Press Email Pitch | Item 28 | Internal or public version decision required |

### 06_VISUAL_ASSETS

| File | Source item | Required |
|---|---:|---|
| Primary discovery graphic | Item 16 / final image file when produced | Required if available |
| Technical diagram set | Item 17 / final diagram files when produced | Optional until produced |
| Investigator photo assets | Item 18 / final photo files when approved | Optional until produced |
| Optional video / animation assets | Item 20 / final video files when produced | Optional |
| Caption and Attribution Sheet | Item 19 | Required if any visual asset is included |
| Press Release Image Set Specification | Item 15 | Optional; include only if useful to media |

### 07_MEDIA_OPERATIONS

| File | Source item | Public inclusion recommendation |
|---|---:|---|
| Media Contact Sheet | Item 24 | Include public version with verified contact details |
| Embargo and Release Instructions | Item 25 | Include only final public-safe version |
| Press Email Pitch | Item 28 | Usually internal; public inclusion optional |
| Interview Preparation Sheet | Item 26 | Usually internal; public inclusion optional |
| Journalist Q&A Brief | Item 27 | Include public version |

### 08_INDEX_AND_ATTRIBUTION

| File | Source item | Required |
|---|---:|---|
| Caption and Attribution Sheet | Item 19 | Yes |
| Document Index | Item 31 when created | Yes after creation |
| File Manifest | Generated at final package assembly | Yes |
| Version / Release Notes | Generated at final package assembly | Yes |

## Required file formats

For public documents, provide at minimum:
- PDF for public distribution where final formatting exists
- TXT or MD for machine-readable access and internal audit continuity
- DOCX only if needed for press editing workflows

Recommended format rule:
- Public-facing distribution: PDF
- Press/editor convenience: DOCX only where useful
- Audit/source continuity: TXT or MD
- Web copy: MD or HTML-ready text

Do not include raw working files unless specifically approved.

## Required visual formats

| Asset type | Recommended public format |
|---|---|
| Graphics | PNG and JPG |
| Diagrams | PNG and PDF if available |
| Portraits | JPG |
| Social graphics | JPG or PNG |
| Video | MP4 H.264 |
| Captions/transcripts | SRT and TXT |

Do not include design source files, editable masters, RAW photo files, or video project files in the public ZIP unless separately approved.

## Public vs internal split

The final package should distinguish between:

### Public ZIP

For journalists and public download. Contains only approved release materials.

### Internal master ZIP

For continuity and reconstruction. May include locked item files, audit files, source materials, drafts, and internal notes.

### Reserved technical archive

For protected technical material. Not included in public release.

This Item 30 specification controls the public ZIP only unless otherwise stated.

## Required public README disclaimer

Use this statement in the public ZIP README:

“The public press kit explains the K-field discovery, its foundation-to-branch hierarchy, and the Mass Bridge focal point. Exact derivation pathways, protected geometry, witness construction details, internal computational machinery, and other proprietary technical materials are not included in this public ZIP.”

## Contact block

Use verified contact details only:

Krytronx, LLC  
[Public Media Contact Placeholder]  
[Public Email Placeholder]  
[Website Placeholder]  
[Press Kit URL Placeholder]

If final contact details are not available, the public ZIP should not be released.

## Version control

Every public press kit ZIP should have:
- Version date
- Release status
- File manifest
- Document index
- Final audit record
- Replacement/supersession note if updated later

Recommended version field:

`Version: PUBLIC vYYYYMMDD`

Recommended release status values:
- Internal draft only
- Hold for release
- Embargoed
- Public release

## File manifest requirements

The final ZIP should include a manifest:

`08_INDEX_AND_ATTRIBUTION/FILE_MANIFEST.csv`

Required fields:
- Folder
- Filename
- Document title
- Source item
- Version date
- Public/restricted status
- File type
- Short description
- Notes

## Document index dependency

The final public ZIP should not be released until Item 31: Citation and Document Index is created and approved, unless a temporary public file manifest is separately approved.

## Placeholder control

Before public release, search the final ZIP contents for unresolved placeholders:

- `[Contact Name Placeholder]`
- `[Email Placeholder]`
- `[Phone Placeholder]`
- `[Website Placeholder]`
- `[Press Kit Download Link Placeholder]`
- `[Release Date Placeholder]`
- `[Release Time Placeholder]`
- `[Embargo Status Placeholder]`
- `[Verification Contact Placeholder]`
- `[Year Placeholder]`
- `[Image Link Placeholder]`
- `[Document Link Placeholder]`

Any unresolved placeholder must either be replaced, removed, or explicitly marked internal-only. Do not release a public ZIP with public-facing unresolved placeholders.

## Required exclusion scan

Before release, scan the ZIP for high-risk terms and file patterns:

High-risk terms:
- proprietary derivation
- exact geometry
- witness table
- orientation data
- internal machinery
- anti-gravity device
- free energy
- private address
- personal phone
- internal draft
- not for public distribution

High-risk file patterns:
- `_DRAFT`
- `_AUDIT` unless public audit inclusion is intended
- `SOURCE_`
- `scratch`
- `working`
- `private`
- `internal`
- `reserved`
- `master`
- `raw`
- `unredacted`

## Public package quality checks

| Check | Pass condition |
|---|---|
| Public-only contents | No internal drafts, reserved files, private data, or unapproved sources included. |
| Lock status | Included documents are locked and approved for public distribution. |
| Placeholder cleanup | No unresolved public-facing placeholders remain. |
| Contact verification | Public contact details are verified. |
| Release timing | Release status matches Item 25. |
| Document index | Public document index or manifest is included. |
| Captions and credits | Visual assets include approved attribution and usage terms. |
| Trade-secret boundary | Reserved derivation details are excluded. |
| File organization | ZIP has clean root folder and clear subfolders. |
| Version control | ZIP filename, README, manifest, and release notes match. |
| Web compatibility | Filenames are readable and safe for download links. |

## Final assembly sequence

Recommended sequence after all relevant items are locked:

1. Confirm final release status and timing.
2. Confirm public media contact.
3. Confirm final landing page URL and press kit URL.
4. Confirm which visual files are final and public-approved.
5. Confirm whether interview prep and press email pitch remain internal or public.
6. Create Item 31: Citation and Document Index.
7. Create public file manifest.
8. Assemble public ZIP.
9. Run placeholder scan.
10. Run exclusion scan.
11. Run link and filename review.
12. Create final package audit.
13. Release only after approval.

## Do-not-release conditions

Do not release the public ZIP if:
- Item 31 has not been created or a temporary manifest has not been approved.
- Contact placeholders remain unresolved.
- Release status is not approved.
- Draft or audit files are included unintentionally.
- Reserved technical material is included.
- Visual assets lack captions or credits.
- Any file contradicts locked public language.
- Any file implies anti-gravity, free energy, product readiness, peer-review acceptance, or institutional endorsement not approved in the package.

## Quality checks before approval of this specification

| Check | Pass condition |
|---|---|
| Required contents | Lists all required public press kit components. |
| Public boundary | Clearly separates public ZIP, internal master ZIP, and reserved technical archive. |
| Trade-secret control | Excludes reconstructive technical material. |
| Placeholder control | Defines required placeholder scan. |
| Version control | Defines filename, README, manifest, and release notes. |
| Dependency control | Defers final public release until document index or manifest is approved. |
| Media utility | Gives journalists a clean, navigable package. |
| Package consistency | Matches landing page, media contact sheet, release instructions, caption sheet, and quote sheet. |

---

Lock status: Approved by user and locked on 2026-07-01T17:54:43+00:00.
