# Item 2 — Controlled Glossary — LOCKED

| Term | Public Definition | Technical Definition | Use Notes / Avoid Saying |
|---|---|---|---|
| K-field | The discovered geometric foundation beneath all known physics. | A directional geometric foundation represented through structured geometry, reciprocal relationships, signed states, branch kernels, projection, and compiler rules. | Avoid “new force” or “mysterious force.” |
| Foundational field | A field beneath the known fields. | The deeper geometric layer from which known physical branches are rendered. | Prefer “foundation beneath known physics.” |
| Generative field | A field that gives rise to physical branches. | A structured geometric source whose downstream expressions appear as time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange. | Avoid implying it is just another field beside known fields. |
| Lattice | A structured geometric organization. | The geometric architecture through which K-field relationships are organized and rendered. | Avoid “crystal lattice” unless discussing actual materials. |
| Geometric framework | The structured form that organizes the discovery. | The dependency chain from geometric structure to reciprocal geometry, branch rendering, and observable physics. | Prefer “framework” over “theory of everything.” |
| Branch expression | A known physical domain emerging from the K-field. | A rendered output of the deeper geometric architecture through a branch-specific kernel and compiler. | Use for matter, gravity, EM, inertia, materials, and energy behavior. |
| Known physics | The established domains of physical behavior. | The observed branches interpreted as downstream expressions of the K-field. | Avoid “physics was wrong.” |
| Matter | The physical branch associated with mass and material existence. | A downstream branch connected through the Mass Bridge and related geometric carrier structure. | Tie to Mass Bridge when technical context allows. |
| Time | A physical branch organized by the K-field. | A rendered branch expression of the deeper geometric foundation. | Avoid unsupported clock-specific claims unless sourced. |
| Gravity | A physical branch organized by the K-field. | A downstream branch related to anisotropic geometry, reciprocal structure, and conditional branch rendering. | Avoid “antigravity.” |
| Electromagnetism | A physical branch organized by the K-field. | A downstream branch connected through the fine/EM bridge and carrier relationships. | Prefer “electromagnetic behavior.” |
| Inertia | A physical branch organized by the K-field. | A rendered branch expression tied to motion, orientation, and geometric structure. | Avoid overclaiming device effects. |
| Material behavior | How materials respond, transition, store, or release energy. | A branch expression involving metastability, lattice response, phase, orientation, and material state selection. | Strong term for applied research. |
| Energy exchange | The transfer, storage, recovery, or conversion of energy. | A branch expression involving metastability modulation, phase-sensitive coupling, and recovery/reset accounting. | Avoid “free energy,” “overunity,” or “energy from nothing.” |
| Mathematical closure | The internal mathematical completion of a relationship. | A derivation where geometric definitions, cofactors, reciprocal metrics, q-states, or carrier relationships close without independent fitting. | Avoid using this as a substitute for every kind of external validation. |
| Experimental support | Observational or measured support for the K-field investigation. | Evidence from metastable anisotropy, directional behavior, recurrence, geometric extraction, and cross-domain comparison. | Use “support” or “demonstrates,” not “irrefutable proof.” |
| Scale-spanning framework | A framework that applies across physical scales. | A geometric architecture interpreted as rendering behavior from nanometer material structure to gigaparsec cosmic organization. | Avoid “explains everything.” |
| Field-coupled technology | Technology designed to interact with the K-field. | Resonant, directional, phase-sensitive systems intended to couple to K-field structure through metastability modulation. | Avoid “miracle device” or “unlimited power.” |
| Mass Bridge | The first hard physical bridge from K-field geometry into matter. | A geometric face-ratio relationship connecting fixed K-field geometry to the proton/electron mass scale. | This is the key press term; use carefully and consistently. |
| Geometric Lock | The state created by the Mass Bridge. | The first physical anchoring of extracted K-field geometry to established physical reality. | The Mass Bridge is the event; Geometric Lock is what the event accomplishes. |
| Fine/EM bridge | The companion bridge into electromagnetic/fine-structure behavior. | A geometric carrier relationship linked to the fine-structure side after the Mass Bridge. | Use after Mass Bridge in chronology. |
| Carrier triangle | The constrained geometric relationship linking major physical witnesses. | A common carrier structure tying mass, fine structure, traversal, and related constants into one geometric relationship. | Avoid calling constants “coincidences.” |
| Metastability modulation | The K-field’s action on systems with more than one available state. | Directional or phase-sensitive influence on state holding, transition, timing, energy storage, and energy release. | Strong public bridge to engineering. |
| Geometric phase space | The fixed structural space through which physical systems move or sample. | The oriented K-field lattice treated as fixed relative to a broader reference frame, with Earth/laboratory motion sampling it. | Avoid “ether.” |
| Downstream witness | A physical constant or behavior that reflects the deeper geometry. | A measured or derived quantity interpreted as a rendered consequence of the K-field dependency chain. | Prefer this over “constant proves everything.” |
| Field-coupled energy extraction | Engineering that attempts to couple to the K-field through phase-sensitive systems. | Resonant, directional, metastable, or branch-sensitive systems designed for net load power after full energy accounting. | Always pair with “net energy accounting.” |

Krytronx is intentionally reserved for the organization boilerplate, not the glossary.
