# Item 21 — Principal Investigator Profile — LOCKED

Status: LOCKED by user approval.  
Target use: Press kit, advisor outreach, institutional packets, website profile page, interview preparation, conference introduction, and media background materials.  
Source basis: Locked Items 1-20, especially the locked Investigator Biography, primary press release, executive summary, public technical backgrounder, FAQ, public glossary, quote library, visual specifications, and caption/attribution sheet.  
Public boundary: This profile is a public-facing investigator profile. It does not disclose proprietary geometry, exact derivation pathways, internal computational machinery, witness tables, unpublished technical material, private personal information, or trade-secret research details.

---

# Principal Investigator Profile

## Profile heading

P. Dwayne Esterline  
Principal, Krytronx, LLC  
Discoverer of the K-field

## Short profile

P. Dwayne Esterline is the owner and Principal of Krytronx, LLC, an independent research firm focused on further development of the K-field discovery. In June 2026, Esterline identified the K-field as a structured geometric foundation beneath known physics, with the Mass Bridge serving as the public focal point that physically anchors the extracted geometry to matter.

Esterline’s background combines industry leadership, technical investigation, systems analysis, and independent research. His professional experience includes senior responsibility for large-scale purchasing and operational systems across multiple North American facilities. His academic background includes a Bachelor of Science from Huntington University and an MBA from Indiana Wesleyan University.

## Expanded profile

P. Dwayne Esterline is the owner and Principal of Krytronx, LLC, an independent research firm now focused exclusively on further development of the K-field discovery. The K-field is presented in the press package as a discovered geometric foundation beneath known physics: a structured foundation from which time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange are treated as branch expressions of a deeper architecture.

Esterline’s investigative work culminated in June 2026 with the identification of the K-field and the Mass Bridge. The Mass Bridge is the public focal point of the discovery narrative because it physically anchors the extracted geometry to matter. Within the approved public framework, this anchoring step transformed the investigation from one based primarily on observation into one organized around computation, hierarchy, and downstream physical witnesses.

Before focusing Krytronx, LLC exclusively on K-field research, Esterline’s career included significant industrial and operational responsibility. In his role as Director of Purchasing, he was responsible for approximately one billion dollars in annual spend across multiple facilities in North America, with staff located in Monroe, Michigan. This background informs the press package’s emphasis on disciplined structure, controlled language, evidence organization, and practical downstream pathways.

Esterline holds multiple degrees, including a Bachelor of Science from Huntington University and an MBA from Indiana Wesleyan University. His work as an independent investigator reflects a broad analytical orientation across systems, physical inference, structured geometry, and technical synthesis.

## Investigator positioning

The approved public positioning is:

“P. Dwayne Esterline is an independent investigator and Principal of Krytronx, LLC, presenting the K-field discovery through a disciplined public press package that separates public explanation from reserved proprietary derivation details.”

This positioning should be used when the profile appears in media packets, institutional outreach, and website biography pages.

## Approved role descriptions

| Use case | Approved wording |
|---|---|
| Short role | Principal, Krytronx, LLC |
| Discovery role | Discoverer of the K-field |
| Press-kit role | Principal Investigator, K-field Discovery |
| Expanded role | Owner and Principal of Krytronx, LLC |
| Public profile role | Independent investigator and Principal of Krytronx, LLC |
| Technical profile role | Independent investigator focused on the K-field discovery and its downstream research pathways |

Avoid unapproved institutional titles, academic titles, government titles, or external affiliations unless separately verified and approved.

## Approved short bios

### 25-word bio

P. Dwayne Esterline is Principal of Krytronx, LLC and discoverer of the K-field, presented as a geometric foundation beneath known physics.

### 50-word bio

P. Dwayne Esterline is the owner and Principal of Krytronx, LLC, an independent research firm focused on further development of the K-field discovery. Esterline identified the K-field in June 2026 as a structured geometric foundation beneath known physics, with the Mass Bridge serving as the discovery’s public anchoring focal point.

### 100-word bio

P. Dwayne Esterline is the owner and Principal of Krytronx, LLC, an independent research firm focused on further development of the K-field discovery. In June 2026, Esterline identified the K-field as a structured geometric foundation beneath known physics. The public press package presents the Mass Bridge as the focal point that physically anchors the extracted geometry to matter, transforming the investigation from observation into computation. Esterline’s background includes industrial leadership, systems analysis, technical investigation, and independent research. He holds a Bachelor of Science from Huntington University and an MBA from Indiana Wesleyan University.

## Interview introduction

Suggested host or journalist introduction:

“Joining us is P. Dwayne Esterline, Principal of Krytronx, LLC and discoverer of the K-field. His press package presents the K-field as a structured geometric foundation beneath known physics, with the Mass Bridge serving as the public focal point that physically anchors the discovery framework.”

## Media background paragraph

For journalists needing context, use:

“Esterline’s K-field work is presented through a public press package that includes a primary press release, technical backgrounder, FAQ, glossary, comparison sheet, controlled visual specifications, and media support materials. The package frames the K-field as a discovered geometric foundation beneath known physics while reserving exact derivation pathways and proprietary technical machinery as trade-secret material.”

## Quote integration

The profile may be paired with one approved Mass Bridge quote from the locked quote library. Recommended pairing:

“The Mass Bridge transformed the investigation from one of observation into one of computation. Once the geometry became physically anchored, the remaining branches of physics became questions of geometric generation rather than independent discovery.”

Use quote integration sparingly. The profile should remain biographical and explanatory, not a technical argument.

## Education and professional background

| Category | Public wording |
|---|---|
| Undergraduate education | Bachelor of Science, Huntington University |
| Graduate education | MBA, Indiana Wesleyan University |
| Business role | Owner and Principal, Krytronx, LLC |
| Research role | Independent investigator focused on further development of the K-field discovery |
| Industrial background | Former Director of Purchasing with responsibility for approximately one billion dollars in annual spend across multiple North American facilities |

Do not include removed or intentionally excluded publication details unless later approved.

## Krytronx positioning

Approved organizational sentence:

“Krytronx, LLC is an independent research firm focused on further development of the K-field discovery.”

Expanded organizational sentence:

“Krytronx, LLC was originally formed to facilitate research and development in applied technical domains and is now focused exclusively on further development of the K-field discovery.”

Use the shorter version in media profiles unless more organizational context is required.

## Tone controls

Preferred tone:
- Professional
- Independent
- Technically disciplined
- Evidence-organized
- Public-facing
- Institutionally readable
- Plain enough for journalists

Avoid tone:
- Celebrity inventor
- Lone-genius myth
- Fringe outsider posture
- Combative anti-establishment posture
- Mystical discovery language
- Product-launch language
- Investment pitch language

## Claims and boundary controls

The profile may state:
- Esterline is Principal of Krytronx, LLC.
- Esterline is the discoverer of the K-field.
- The discovery period was June 2026.
- The K-field is presented as a structured geometric foundation beneath known physics.
- The Mass Bridge is the public focal point and physical anchoring hinge.
- Krytronx, LLC is focused on further development of the discovery.
- Proprietary derivation details remain reserved.

The profile should not state:
- University endorsement
- Peer-reviewed acceptance unless separately achieved
- Government validation
- Finished commercial devices
- Demonstrated anti-gravity technology
- Free-energy production
- Exact protected derivation details
- Unapproved personal or private biographical details

## Website profile layout

Recommended structure:
1. Name and role
2. Short profile paragraph
3. K-field discovery paragraph
4. Background and education paragraph
5. Krytronx paragraph
6. Press contact or media materials link

Recommended page title:

“P. Dwayne Esterline — Principal Investigator, K-field Discovery”

Recommended meta description:

“P. Dwayne Esterline, Principal of Krytronx, LLC, is the discoverer of the K-field, presented as a structured geometric foundation beneath known physics.”

## Press kit placement

Place this profile after:
- Primary press release
- Executive summary / media brief
- Investigator biography

Place it before:
- Quote sheet
- Organization boilerplate
- Media contact sheet
- Interview preparation sheet

## Quality checks before approval

| Check | Pass condition |
|---|---|
| Role clarity | Clearly identifies P. Dwayne Esterline, Krytronx, LLC, and K-field discovery role. |
| Consistency | Matches locked biography, press release, FAQ, glossary, and technical backgrounder. |
| Public boundary | Does not disclose proprietary derivation details or private information. |
| Tone discipline | Avoids sensational, mystical, product-launch, or combative language. |
| Media utility | Contains short, medium, and expanded versions usable by journalists. |
| Credential accuracy | Uses only approved education and professional background details. |
| Package fit | Complements but does not duplicate the locked investigator biography. |

---

Lock status: Approved by user and locked on 2026-07-01T17:32:14+00:00.
