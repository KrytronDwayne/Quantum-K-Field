# Item 25 — Embargo and Release Instructions — LOCKED

Status: LOCKED by user approval.  
Target use: Press release distribution, journalist outreach, institutional coordination, website publication, press-kit download timing, image/video release control, interview scheduling, and internal release coordination.  
Source basis: Locked Items 1-24, especially the primary press release, media brief, public technical backgrounder, FAQ, Organization Boilerplate, Caption and Attribution Sheet, Quote Sheet, Media Contact Sheet, and visual/media asset specifications.  
Public boundary: This document controls release timing, embargo language, attribution rules, and publication conditions only. It does not disclose proprietary geometry, exact derivation pathways, witness tables, internal computational machinery, unreleased devices, private contact details, or trade-secret technical material.

---

# Embargo and Release Instructions

## Purpose

This document establishes controlled instructions for timing, embargo status, publication conditions, attribution, image usage, verification contact, and release coordination for the K-field discovery press package.

The document is intentionally placeholder-based until final release logistics are approved. No release date, release time, embargo lift time, URL, media contact, or public contact detail should be inferred or invented.

## Release status summary

| Field | Current value |
|---|---|
| Release status | Pending final approval |
| Public release date | [Release Date Placeholder] |
| Public release time | [Release Time Placeholder] |
| Time zone | America/Chicago unless otherwise specified |
| Embargo status | [Embargo Status Placeholder: No embargo / Embargoed / Hold for release] |
| Embargo lift date | [Embargo Lift Date Placeholder] |
| Embargo lift time | [Embargo Lift Time Placeholder] |
| Press kit URL | [Press Kit Download Link Placeholder] |
| Website URL | [Website Placeholder] |
| Media contact | [Media Contact Placeholder] |
| Verification contact | [Verification Contact Placeholder] |

## Release-date rule

Do not publish, distribute, pitch, post, upload, or externally circulate the final public press package until the release date and release time are explicitly approved.

If release timing is not finalized, use:

“Release timing pending final approval.”

Do not use relative dates such as “today,” “tomorrow,” or “next week” in distribution materials unless paired with the exact calendar date and time zone.

## Embargo-status options

Select one of the following before public distribution.

| Status | Meaning | Use condition |
|---|---|---|
| No embargo | Materials may be published upon receipt or at the stated release time | Use only when immediate publication is approved |
| Embargoed | Materials may be shared with selected recipients before publication, but not published until the embargo lift time | Use for controlled journalist pre-briefing |
| Hold for release | Materials should not be shared externally until the release time | Use when no pre-briefing is intended |
| Internal draft only | Materials remain internal and should not be distributed | Use before final contact, URL, date, and legal checks are complete |

Current default until approved:

“Internal draft only.”

## Recommended embargo language

If embargoed release is selected, use:

“EMBARGOED UNTIL [Date], [Time] [Time Zone]. These materials are provided for advance review only and may not be published, quoted, posted, excerpted, or distributed externally before the embargo lift time without written approval from Krytronx, LLC.”

If no embargo is selected, use:

“For immediate release beginning [Date], [Time] [Time Zone].”

If hold-for-release is selected, use:

“HOLD FOR RELEASE UNTIL [Date], [Time] [Time Zone]. Do not distribute publicly before the stated release time.”

If still internal, use:

“INTERNAL DRAFT — NOT FOR PUBLIC DISTRIBUTION.”

## Required top-of-release header

Use one of the following in the primary press release and downloadable press materials.

### For immediate release

FOR IMMEDIATE RELEASE  
[Date]  
[Time Zone if needed]

### Embargoed

EMBARGOED UNTIL [Date], [Time] [Time Zone]

### Hold for release

HOLD FOR RELEASE UNTIL [Date], [Time] [Time Zone]

### Internal draft

INTERNAL DRAFT — NOT FOR PUBLIC DISTRIBUTION

## Approved publication language

Approved short description:

“The K-field is presented as a discovered geometric foundation beneath known physics, physically anchored by the Mass Bridge.”

Approved longer description:

“The K-field discovery is presented through a public press package describing a structured geometric foundation beneath known physics, with the Mass Bridge serving as the physical anchoring focal point between extracted geometry and matter.”

Approved public/reserved boundary statement:

“The public materials explain the K-field discovery, its hierarchy, and the Mass Bridge focal point while preserving exact derivation pathways and proprietary technical machinery as reserved technical material.”

Approved organization description:

“Krytronx, LLC is an independent research firm focused on further development of the K-field discovery.”

Approved investigator identification:

“P. Dwayne Esterline, Principal of Krytronx, LLC and discoverer of the K-field.”

## Required attribution

For quotes:

— P. Dwayne Esterline, Principal of Krytronx, LLC and discoverer of the K-field

For graphics and diagrams:

“Image credit: Krytronx, LLC / K-field Discovery Press Materials.”

For portraits:

“Photo credit: Krytronx, LLC / K-field Discovery Press Materials.”

For video:

“Video credit: Krytronx, LLC / K-field Discovery Press Materials.”

For documents:

“Document prepared as part of the K-field Discovery Press Materials by Krytronx, LLC.”

## Image and visual asset usage terms

Approved visual assets may be used for editorial coverage of the K-field discovery announcement when paired with the approved caption, credit line, and usage statement.

Default visual usage statement:

“Approved for use in coverage of the K-field discovery announcement. Do not alter in ways that imply a completed commercial product, released proprietary derivation, anti-gravity device, free-energy claim, metaphysical interpretation, institutional endorsement not stated in the approved materials, or exact disclosure of protected geometry.”

Prohibited image uses:
- Cropping out the Mass Bridge when it is central to the image meaning.
- Adding unsupported claims or device language.
- Adding formulas, witness values, or protected derivation details.
- Pairing assets with anti-gravity, free-energy, occult, mystical, alien, or sensational imagery.
- Removing required credit lines.
- Implying third-party endorsement.

## Quote usage terms

Approved quotes may be used only as listed in the locked Quote Sheet unless a revised quote is separately approved.

Quote handling rules:
- Do not change meaning.
- Do not add technical claims into a quote.
- Do not attribute quotes to institutions or reviewers.
- Do not imply peer-reviewed validation unless separately achieved.
- Do not pair quotes with prohibited imagery.
- Use the approved attribution line.

## Permitted release materials

The following materials may be released only after final release authorization:

| Material | Release condition |
|---|---|
| Primary press release | Release date/time approved |
| Executive summary / media brief | Release date/time approved |
| Public technical backgrounder | Release date/time approved |
| FAQ | Release date/time approved |
| Public glossary | Release date/time approved |
| Comparison sheet | Release date/time approved |
| Quote sheet | Release date/time approved |
| Organization boilerplate | Release date/time approved |
| Visual assets | Captions/credits/usage terms approved |
| Investigator photo assets | Photo approval and credit terms approved |
| Optional video assets | Rights, captions, transcript, and export review complete |
| Press-kit ZIP | Final packet audit complete |

## Materials not approved for public release

Do not release:
- Proprietary geometry
- Exact derivation pathways
- Internal branch-generation rules
- Projection/compiler machinery
- Witness construction details
- Complete witness tables unless separately approved
- Orientation data or reconstructive numerical details
- Unreleased device concepts or engineering claims
- Private contact information
- Internal drafts marked not for distribution
- Any file not included in the approved final press kit

## Distribution stages

### Stage 1 — Internal final review

Use when package is still being assembled.

Status label:
“Internal Draft — Not for Public Distribution”

Actions:
- Confirm locked item status.
- Replace approved placeholders only.
- Verify contact details.
- Verify release date/time.
- Verify press kit URL.
- Verify captions and credits.
- Run final audit.

### Stage 2 — Embargoed pre-briefing, if selected

Use when selected journalists or institutional contacts receive materials before publication.

Status label:
“Embargoed Until [Date], [Time] [Time Zone]”

Actions:
- Include embargo notice in email and document headers.
- Confirm recipients acknowledge embargo.
- Provide approved materials only.
- Log recipients.
- Avoid sending reserved technical material.
- Route technical questions through approved response language.

### Stage 3 — Public release

Use at approved release time.

Status label:
“For Immediate Release”

Actions:
- Publish website landing page.
- Activate press kit download link.
- Send press release.
- Send pitch emails.
- Publish approved social materials.
- Confirm public links work.
- Archive final released package.

### Stage 4 — Post-release response

Use after public distribution.

Actions:
- Track media inquiries.
- Route interview requests.
- Confirm quote accuracy.
- Provide approved visuals.
- Correct misstatements using approved language.
- Preserve inquiry records.

## Release checklist

| Check | Pass condition |
|---|---|
| Release timing | Exact date, time, and time zone approved |
| Embargo status | No embargo, embargoed, hold-for-release, or internal-only status selected |
| Contact details | Public media contact verified |
| Press kit link | Final URL verified |
| Primary documents | All approved public documents locked |
| Visual assets | Captions, credits, and usage terms approved |
| Quote sheet | Approved quote sheet locked |
| Organization boilerplate | Approved boilerplate locked |
| Technical boundary | Proprietary derivation material excluded |
| Privacy | No private contact or personal information exposed |
| Rights | Third-party assets cleared or excluded |
| Final audit | Package audit completed before release |

## Verification contact

All release-status, embargo, quote, image-use, and document-version questions should route to:

[Verification Contact Placeholder]  
Krytronx, LLC  
[Verification Email Placeholder]  
[Verification Phone Placeholder — Optional]  
[Website Placeholder]

If no separate verification contact is created, route verification requests to the approved media contact.

## Correction language for premature or inaccurate publication

If a recipient publishes before the approved release time:

“The materials were provided under release restrictions and were not approved for publication before [Date], [Time] [Time Zone]. Please remove or correct the publication until the release restriction lifts.”

If a publication misstates the discovery:

“Please correct the description to the approved public framing: the K-field is presented as a discovered geometric foundation beneath known physics, physically anchored by the Mass Bridge.”

If a publication implies unsupported technology:

“Please remove language implying a completed commercial product, anti-gravity device, free-energy system, or released proprietary derivation. The approved framing is a foundational discovery and future research pathway.”

If a publication omits required credit:

“Please add the approved credit line: [Approved Credit Line].”

## Internal release log template

| Date/time | Action | Recipient / platform | Materials sent | Embargo status | Contact person | Notes |
|---|---|---|---|---|---|---|
| [Placeholder] | [Placeholder] | [Placeholder] | [Placeholder] | [Placeholder] | [Placeholder] | [Placeholder] |

## Public release notes

Before public release:
- Remove “Draft” labels from final public documents.
- Keep internal draft records archived.
- Use only approved public versions.
- Confirm that downloadable ZIP filenames match final package naming.
- Confirm that no file contains hidden private notes, internal comments, or unresolved placeholders.
- Confirm that final documents do not include unsupported contact details or raw source files reserved for internal use.

## Quality checks before approval

| Check | Pass condition |
|---|---|
| Timing control | Release date/time and embargo rules are explicit or placeholder-controlled. |
| No invented details | No date, time, contact, URL, or embargo status is invented. |
| Attribution control | Required quote, image, photo, video, and document credit lines are included. |
| Image-use control | Visual usage restrictions match locked Item 19. |
| Technical boundary | Reserved technical material is excluded from public release. |
| Privacy control | Private contact details are not exposed. |
| Release workflow | Internal, embargoed, public, and post-release stages are defined. |
| Correction path | Misstatement and premature-publication correction language is included. |
| Package consistency | Matches media contact sheet, quote sheet, boilerplate, captions, and press release. |

---

Lock status: Approved by user and locked on 2026-07-01T17:41:34+00:00.
