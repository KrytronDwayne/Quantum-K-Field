# Item 16 — Primary Discovery Graphic Production Brief — LOCKED

Status: LOCKED by user approval.  
Revision reason: Adds the approved base color system and primary font controls to the Item 16 production brief.  
Target use: Central press-kit graphic, website hero image, social preview, presentation cover, and visual anchor for the K-field discovery announcement.  
Source basis: Locked Items 1-15, especially the locked primary message framework, controlled glossary, discovery chronology, Mass Bridge quote library, public technical backgrounder, comparison sheet, locked image set specification, and user-approved color guidance.  
Public boundary: This brief controls the primary public graphic only. It does not disclose proprietary geometry, exact orientation data, derivation pathways, internal branch-generation rules, projection/compiler machinery, numerical witness construction, or trade-secret technical details.

---

# Primary Discovery Graphic Production Brief

## Purpose

The primary discovery graphic is the central visual identity for the K-field public announcement. It should communicate the discovery in one press-ready image: the K-field is the discovered geometric foundation beneath known physics, and the Mass Bridge is the physical anchoring hinge that connects the extracted geometry to matter.

This graphic should function without requiring a technical reader. A viewer should understand the hierarchy immediately: a deeper structured foundation is below; known physical branches are above; the Mass Bridge sits at the center as the anchor between the two. The graphic should support the press release and media brief without turning the discovery into a speculative entertainment image.

## Controlling visual statement

The primary graphic should visually express this sentence:

“The K-field is the discovered geometric foundation beneath known physical branches, physically anchored by the Mass Bridge.”

The visual should reinforce three locked distinctions: foundation rather than force, geometry before constants, and branch-level physics rather than replacement of known physics.

## Required versions

| Asset ID | Filename | Aspect ratio | Primary use | Status |
|---|---|---:|---|---|
| IMG-01A | k_field_primary_discovery_graphic_square.png | 1:1 | Press kit cover, social preview, article thumbnail | Pending production |
| IMG-01B | k_field_primary_discovery_graphic_landscape.png | 16:9 | Website hero, presentation title slide, video thumbnail | Pending production |
| IMG-01C | k_field_primary_discovery_graphic_print.png | 16:9 or square master | Print-ready media package | Pending production |

The square and landscape versions should be visually related, not separate concepts. The same underlying composition should be adapted to each crop.

## Base color system

Use the following role-based palette as the controlling color system for the primary discovery graphic and its derivative crops.

| Role | Color | Allocation | Primary function | Required use |
|---|---:|---:|---|---|
| Base / Credibility | `#0F172A` | 60% | Structural authority, technological maturity, institutional trust | Backgrounds, deep panels, title areas, primary text zones, macro framing |
| Logic / Navigation | `#0EA5E9` | 30% | Analytical focus, reduced visual fatigue, clear hierarchy | Section markers, branch pathways, subheadings, borders, connective lines, standard links |
| Impulse / Action | `#F97316` | 10% | High-salience capture and conversion emphasis | Mass Bridge highlight, key focal node, call-to-action accents, critical terminal paths |
| Progression Slate 1 | `#1E293B` | Variable within base family | First transition step | Near-background planes, lower-depth geometry |
| Progression Slate 2 | `#334155` | Variable within base family | Second transition step | Mid-depth geometry, branch separation panels |
| Progression Slate 3 | `#64748B` | Variable within base family | Third transition step | Secondary geometry, quiet labels, explanatory step transitions |

### Color hierarchy rules

The graphic should be anchored by `#0F172A`, not by black, white, purple, or cosmic gradients. This gives the public image a technology-business press identity rather than an entertainment poster identity.

Use `#0EA5E9` as the main logic color. Branches, connectors, pathway lines, structural borders, and technical navigation elements should normally use cyan-blue rather than orange.

Use `#F97316` sparingly. The Mass Bridge may use amber-orange as the highest-salience focal element. Do not spread orange across all branch pathways. Overuse weakens the visual hierarchy and makes the image look promotional rather than evidentiary.

Use the slate progression `#1E293B -> #334155 -> #64748B` to show layered complexity without requiring a legend. The darker slate should remain closer to the background and lower foundation. The lighter slate may appear in upper branch separation, secondary labels, and subtle explanatory steps.

### Accessibility and reproduction controls

Maintain strong contrast between text and background. For dark backgrounds, use light text such as near-white or very pale slate only where needed, while keeping the approved palette visually dominant. Do not use low-contrast cyan on pale gray or orange on mid-slate for small labels.

The palette should reproduce acceptably in PNG, JPG, PDF, slide, and print contexts. Avoid color effects that depend on extreme glow, transparency, or monitor-only luminance. Gradients are allowed only when they remain within the approved slate/cyan/orange system.

## Primary fonts

Use a restrained technical-business typography system focused on reproducibility, readability, and press-package consistency. Do not use decorative, futuristic, novelty, sci-fi, occult, handwritten, or display-only typefaces.

| Role | Preferred font | Acceptable fallbacks | Usage |
|---|---|---|---|
| Primary headline | Inter SemiBold | Aptos Display, Aptos, Arial, Helvetica, Liberation Sans | “K-field Discovery,” section headers, hero text |
| Body and labels | Inter Regular / Medium | Aptos, Arial, Helvetica, Liberation Sans | Branch labels, captions, explanatory text, press-kit graphic labels |
| Technical micro-labels | IBM Plex Mono | Cascadia Mono, Consolas, Liberation Mono, Courier New | Optional small technical tags, coordinate-style labels, file/asset annotations |

### Font selection rationale

Inter is selected as the preferred primary family because it is clean, modern, highly readable at web and presentation sizes, and suitable for technical-business communication. Aptos, Arial, Helvetica, and Liberation Sans are approved fallbacks because they preserve reproducibility across Microsoft Office, web, Linux, and general media workflows.

IBM Plex Mono is selected only for optional technical micro-labels. It should not dominate the composition. Monospace should be used as a signal of controlled technical precision, not as the primary visual identity.

### Typography rules

Use no more than two font families in any final graphic: one sans-serif family for headline/body/labels and one monospace family only if micro-labels are required.

Recommended text weights: SemiBold for main title, Medium for branch labels, Regular for captions. Avoid ultra-light weights, condensed fonts, heavy black weights, all-caps blocks, and excessive letter spacing.

If the image is exported to PDF or print, fonts should be embedded or converted to outlines by the designer. Do not distribute font files inside the press package.

## Composition hierarchy

| Layer | Visual role | Required treatment |
|---|---|---|
| Lower layer | K-field foundation | Structured, dimensional, ordered geometric foundation; abstract enough to avoid protected geometry; primarily slate progression with cyan structural definition. |
| Central anchor | Mass Bridge | Keystone, bridge, hinge, or lock motif connecting lower geometry to upper branch field; may use the controlled amber-orange accent. |
| Upper layer | Known physical branches | Clean branch pathways into labeled or symbolic domains; primarily cyan-blue with restrained slate supports. |
| Background | Scientific press context | Deep slate blue-black, modern, disciplined; avoid dramatic cosmic spectacle. |
| Optional title | Identification | Minimal text only: “K-field Discovery” or no title if the image will be paired with a headline. |

## Layout requirements

The lower half or lower third of the image should contain a structured geometric layer. It may look like a precise dimensional lattice, nested geometric surface, or ordered field substrate. It should not reproduce exact internal geometry, exact cell measurements, numerical relationships, or diagrammatic derivation content.

The central Mass Bridge should sit at the transition point between the lower foundation and upper branch domain. It may be represented as an illuminated keystone, a technical bridge, an interlocking hinge, or a lock-like structural element. It must look physically anchored and computationally precise, not magical or metaphysical. Use the impulse color `#F97316` here if one focal accent is needed.

The upper branch region should show seven clean emergent pathways or domains: time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange. Labels are permitted but not mandatory. If labels are used, they must be readable at web size and must not crowd the image.

The landscape version should leave safe headline space on one side. The square version should place the strongest focal structure near center and remain readable as a small thumbnail.

## Approved labels

Preferred label set:

| Label | Use |
|---|---|
| K-field | Lower foundation label, if used. |
| Mass Bridge | Central anchor label, if used. |
| Known Physics | Optional umbrella label above branches. |
| Time | Upper branch label. |
| Matter | Upper branch label. |
| Gravity | Upper branch label. |
| Electromagnetism | Upper branch label. |
| Inertia | Upper branch label. |
| Material Behavior | Upper branch label. |
| Energy Exchange | Upper branch label. |

If the image becomes too text-heavy, use only three labels: K-field, Mass Bridge, and Known Physics. The detailed branch names can be supplied in the caption.

## Design style

The style should be clean, dimensional, modern, and publication-ready. It may use subtle depth, structured light, thin geometric lines, layered planes, restrained contrast, and precise branch pathways. The design should suggest computation and physical structure, not cosmic fantasy.

Approved style descriptors: scientific visualization, structured geometry, technical press graphic, dimensional foundation, clean hierarchy, controlled illumination, modern research announcement, engineered visual order, deep slate background, cyan logic pathways, amber Mass Bridge accent.

Avoid style descriptors: portal, occult, sacred geometry, alien device, free-energy machine, anti-gravity engine, mystical field, cosmic explosion, wormhole, conspiracy board, magical lattice, divine geometry, neon rainbow palette, purple cosmic vortex, fantasy energy core.

## Primary generation brief

Create a clean, professional, press-ready scientific visualization for the K-field discovery. Use a deep slate blue-black base color `#0F172A`, cyan-blue logic pathways `#0EA5E9`, restrained amber-orange emphasis `#F97316`, and slate progression tones `#1E293B`, `#334155`, and `#64748B`. Show a precise structured geometric foundation beneath known physics. Place a central Mass Bridge motif at the transition point, physically anchoring the lower geometric foundation to the upper branch expressions. The Mass Bridge may carry the amber-orange focal accent. The upper branches should suggest time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange as organized expressions of one deeper structure. Use clean technical-business typography, preferably Inter with Aptos/Arial/Helvetica fallbacks. The composition should be disciplined, modern, technical, and suitable for a major discovery press release. Do not show exact proprietary geometry, equations, numerical derivations, witness tables, orientation data, internal computational machinery, finished devices, anti-gravity claims, free-energy imagery, mystical symbolism, occult geometry, alien technology, chaotic science-fiction effects, decorative fonts, or uncontrolled color palettes.

## Square version production brief

Create the square primary K-field discovery graphic for a press kit cover and social preview. Use a centered composition. The lower half should show an abstract structured geometric foundation labeled or implied as the K-field. A central Mass Bridge keystone, bridge, hinge, or lock element should connect this foundation to organized physical branches above. Apply the approved palette: deep slate blue-black base, cyan-blue logic pathways, slate progression geometry, and one restrained amber-orange focal accent at the Mass Bridge. Use Inter or an approved sans-serif fallback for labels. The branch region should remain clean and readable, with optional minimal labels for time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange. The image must be strong as a thumbnail and must avoid exact proprietary geometry or sensational science-fiction styling.

## Landscape version production brief

Create the landscape primary K-field discovery graphic for a website hero and presentation cover. Use the same visual identity as the square version, but expand the horizontal layout with safe space for a headline. The lower field should show ordered geometric structure in the slate progression range; the center should feature the Mass Bridge as the physical anchor with controlled amber-orange emphasis; the upper region should show known physical branches emerging through cyan-blue logic pathways from the common foundation. Keep the design press-ready, precise, and restrained. Use Inter or approved sans-serif fallbacks. Avoid exact formulas, protected geometry, numerical construction, product imagery, anti-gravity implication, free-energy implication, mystical or occult visual cues, and uncontrolled color effects.

## Caption controls

Short caption:

“The K-field is presented as a discovered geometric foundation beneath known physical branches, physically anchored by the Mass Bridge.”

Long caption:

“This primary discovery graphic represents the K-field as a structured geometric foundation beneath known physics. The central Mass Bridge motif marks the public focal point of the discovery narrative: the transition where independently extracted geometry becomes physically anchored to matter, allowing later physical relationships to be treated as downstream witnesses of the fixed structure.”

Credit line:

“Image credit: Krytronx, LLC / K-field Discovery Press Materials.”

Usage-rights statement:

“Approved for use in coverage of the K-field discovery announcement. Do not alter in ways that imply a completed commercial product, released proprietary derivation, anti-gravity device, free-energy claim, metaphysical interpretation, or exact disclosure of protected geometry.”

## Alt text

Recommended alt text:

“Scientific visualization showing an ordered geometric foundation labeled as the K-field beneath branching domains of known physics, connected by a central Mass Bridge structure.”

Short alt text:

“K-field foundation beneath known physics with central Mass Bridge.”

## File and export requirements

| Output | Filename | Format | Minimum target |
|---|---|---|---|
| Square web | k_field_primary_discovery_graphic_square.png | PNG | 2000 × 2000 px |
| Square social | k_field_primary_discovery_graphic_square_social.jpg | JPG | 1600 × 1600 px |
| Landscape web | k_field_primary_discovery_graphic_landscape.png | PNG | 2400 × 1350 px |
| Landscape hero | k_field_primary_discovery_graphic_hero.jpg | JPG | 2400 × 1350 px |
| Print master | k_field_primary_discovery_graphic_print.png | PNG or TIFF | Long edge at least 3000 px |
| Internal master | k_field_primary_discovery_graphic_master.* | Editable source if available | Retain internally |

## Brand and style token summary

| Token | Value |
|---|---|
| Primary background | `#0F172A` |
| Logic pathway / link color | `#0EA5E9` |
| Focal impulse accent | `#F97316` |
| Slate depth progression | `#1E293B`, `#334155`, `#64748B` |
| Preferred headline font | Inter SemiBold |
| Preferred body/label font | Inter Regular / Medium |
| Technical micro-label font | IBM Plex Mono |
| Sans-serif fallbacks | Aptos, Arial, Helvetica, Liberation Sans |
| Monospace fallbacks | Cascadia Mono, Consolas, Liberation Mono, Courier New |

## Quality checks before approval

The graphic should pass these checks before final release:

| Check | Pass condition |
|---|---|
| Message clarity | Viewer can identify foundation, anchor, and branches without reading a long caption. |
| Mass Bridge priority | The central anchor is visible and clearly connects geometry to physical branches. |
| Palette compliance | The graphic follows the approved 60/30/10 role-based palette and slate progression system. |
| Typography compliance | Fonts follow the approved technical-business system and remain readable at web size. |
| Trade-secret boundary | No exact geometry, formulas, witness tables, protected numbers, or internal machinery are visible. |
| Public safety | No free-energy, anti-gravity, finished-device, mystical, occult, or alien cues. |
| Readability | Any labels remain readable at website and social preview size. |
| Brand neutrality | Looks like a scientific discovery graphic, not an entertainment poster or speculative product ad. |
| Package consistency | Supports the press release, technical backgrounder, FAQ, glossary, comparison sheet, and image-set specification. |

## Editorial control rule

The primary discovery graphic should not try to explain the entire technical framework. Its job is to establish the public visual hierarchy: K-field foundation, Mass Bridge anchor, known physics branches. All other images in the visual set should be subordinate to that hierarchy.

---

Lock status: Approved by user and locked on 2026-07-01T17:18:35+00:00.
