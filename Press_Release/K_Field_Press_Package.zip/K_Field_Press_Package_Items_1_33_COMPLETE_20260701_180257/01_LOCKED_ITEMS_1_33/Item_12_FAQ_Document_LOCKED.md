# Item 12 — FAQ Document — DRAFT

Status: Draft for user review. Not locked.
Target use: Frequently asked questions document for journalists, advisors, institutional contacts, web readers, and technically skeptical reviewers.
Source basis: Locked Items 1-11, approved public/trade-secret boundary, and controlling press package outline.

---

# K-field Discovery FAQ

## 1. What is the K-field?

The K-field is the discovered geometric foundation beneath known physics. It is described as a precise, structured geometric field from which time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange emerge as branch expressions of one deeper architecture.

In public language, the K-field is the foundation beneath the fields.

## 2. Who discovered the K-field?

The K-field was discovered by P. Dwayne Esterline, Principal Investigator and founder of Krytronx, LLC, an independent research organization focused on the continued development of the K-field framework.

## 3. When was it discovered?

The discovery was formalized in June 2026 after an extended investigation into direction-dependent behavior in metastable systems, large-scale geometric recurrence, galaxy-oriented geometric extraction, and the Mass Bridge that physically anchored the geometry.

## 4. Why is the K-field important?

The K-field is important because it proposes a single geometric foundation beneath major physical domains that are normally treated separately. Instead of beginning with matter, gravity, electromagnetism, inertia, material response, timing behavior, and energy exchange as independent starting points, the K-field framework interprets them as downstream branch expressions of one deeper structure.

## 5. What does the K-field unify?

The K-field framework connects the major branches of known physical behavior through a common geometric foundation. Public-facing materials describe the connected branches as time, matter, gravity, electromagnetism, inertia, material behavior, and energy exchange. The research program also treats physical constants as downstream witnesses of the same underlying structure after geometric anchoring.

## 6. How was the K-field discovered?

The investigation began with repeated direction-dependent behavior in metastable systems. Early results appeared to correlate with lunar motion, Earth rotation, and related celestial cycles. The first major turning point occurred when those cycles were reinterpreted as sampling motions rather than causes. Under this interpretation, the laboratory was moving through a fixed anisotropic structure.

That shift changed the investigation from searching for a local forcing mechanism to identifying the structure being sampled. Local lattice-like evidence, recurrence analysis, and galaxy-oriented analysis then converged on a common geometric framework. The Mass Bridge provided the physical anchor that connected the extracted geometry into known physical reality.

## 7. What evidence supports the discovery?

The public evidence sequence includes repeated metastable anisotropy observations, the sampler-not-cause inversion, local structural evidence, large-scale recurrence, galaxy-oriented geometry extraction, the Mass Bridge, the Geometric Lock, and downstream witness expansion across physical domains.

The press package separates the public evidence sequence from proprietary derivation machinery. The detailed geometry, exact orientation details, branch-generation algorithms, computational workflow, perturbation pathways, and internal formula machinery are retained as trade secrets.

## 8. Is the discovery experimental, mathematical, or both?

Both. The investigation began with empirical observations of direction-dependent behavior in metastable systems. It then developed into a mathematical and geometric reconstruction program. The Mass Bridge is presented as the hinge between these phases because it connected the extracted geometry to the proton/electron mass relationship and changed the work from pattern investigation into geometric generation.

## 9. How does the K-field relate to known physics?

Known physics is treated as the visible branch layer. The K-field is treated as the deeper geometric foundation beneath that layer. In this framing, established physical behavior remains observable and useful, but the K-field provides a proposed source architecture from which those behaviors are generated and organized.

## 10. Does the K-field replace existing physics?

No. The K-field is not framed as a simple replacement for existing physics. It is framed as an underlying geometric foundation from which known physical branches arise. Existing physics describes the branch-level behavior; the K-field framework addresses the deeper architecture beneath those branches.

## 11. What does “generative lattice” mean?

“Generative lattice” means a structured geometric organization that gives rise to downstream physical expressions. The word “lattice” is used in the geometric sense, not as a claim that space is an ordinary crystal. In the K-field framework, the lattice is the organized geometric architecture through which physical branches are rendered.

## 12. Why is the Mass Bridge so important?

The Mass Bridge is the central hinge of the discovery. It provided the first hard physical bridge from the extracted K-field geometry into matter by connecting the fixed geometric face relationship to the proton/electron mass relationship.

Before the Mass Bridge, the investigation involved observations, recurrence, and geometric reconstruction. After the Mass Bridge, the geometry became physically anchored and could be used as the basis for downstream geometric generation.

## 13. What is the Geometric Lock?

The Geometric Lock is the state created by the Mass Bridge. It means the extracted geometry became physically anchored before broad comparison with known physical constants. After the Geometric Lock, additional physical quantities were evaluated as downstream witnesses rather than construction inputs.

## 14. Were known physical constants used to construct the geometry?

No. The public chronology states that scientific constants were intentionally excluded during the initial galaxy-oriented geometry extraction. The geometry was extracted first. The Mass Bridge then physically anchored it. Only after that were known physical constants evaluated as downstream witnesses of the fixed geometry.

## 15. What technologies could follow from the K-field?

The applied pathway is field-coupled technology: resonant, directional, phase-sensitive interaction with the K-field through orientation, metastability, material state, and controlled system response. Near-term research pathways include metastability modulation, materials response, resonant systems, precision instrumentation, directional coupling studies, and disciplined energy-exchange accounting.

This should not be described as free energy, overunity, anti-gravity, or a miracle device pathway. The approved language is field-coupled technology.

## 16. What are the next validation steps?

Next validation steps include further mathematical development, independent review of public-facing materials, structured experimental planning, materials-response testing, resonant coupling studies, precision instrumentation work, and continued comparison of downstream witnesses against the locked geometric framework. Public materials should distinguish direct observations, mathematical derivations, dataset-supported results, inferences, engineering implications, and open research targets.

## 17. Is there a technical paper?

The press package includes a public technical backgrounder, evidence inventory, discovery chronology, controlled glossary, investigator biography, approved quote library, and derivative media materials. A more formal technical release may be developed separately. The rigorous derivation machinery and proprietary computational details are not part of the public press package.

## 18. Why are some technical details withheld?

The detailed technical machinery is being held as trade secret material. The public package is designed to explain the discovery, its chronology, evidence sequence, Mass Bridge significance, Geometric Lock, and applied implications without releasing proprietary geometry, exact orientation details, branch-generation algorithms, computational workflow, perturbation pathways, or internal formula machinery.

## 19. Is there a media contact?

Yes. The media contact information will be finalized before release.

Current placeholder:

[Name]  
[Title]  
Krytronx, LLC  
[Email]  
[Phone]  
[Website]

## 20. Can P. Dwayne Esterline be interviewed?

Yes, pending scheduling and release coordination. Interview requests should be directed through the media contact listed in the final press package.

## 21. What terms should journalists use?

Preferred terms include K-field, geometric foundation, foundation beneath known physics, foundation beneath the fields, structured geometry, branch expressions, Mass Bridge, Geometric Lock, downstream witnesses, metastability modulation, and field-coupled technology.

## 22. What terms should journalists avoid?

Avoid describing the K-field as a theory of everything, final theory, ether, hidden energy, free energy, overunity, anti-gravity, mystical force, or a conventional crystal lattice. The K-field should not be described as another isolated force. It should be described as the geometric foundation beneath the known fields.

## 23. What is the shortest accurate description?

The K-field is the discovered geometric foundation beneath known physics: a structured field from which the familiar branches of physical behavior emerge as expressions of one deeper architecture.
