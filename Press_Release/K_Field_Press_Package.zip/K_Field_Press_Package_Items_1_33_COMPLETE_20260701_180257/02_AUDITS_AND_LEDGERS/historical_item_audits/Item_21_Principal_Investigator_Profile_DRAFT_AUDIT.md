# Item 21 — Principal Investigator Profile — Draft Audit

Audit timestamp UTC: 2026-07-01T17:29:12+00:00

## Scope

Reviewed Item 21 against the controlling press package outline, locked Items 1-20, the locked Investigator Biography, primary press release, executive summary, technical backgrounder, FAQ, glossary, quote library, and institutional/media positioning rules.

## Result

PASS WITH REVIEW REQUIRED.

The draft satisfies the next investigator/institutional materials step by creating a public-facing Principal Investigator Profile distinct from the longer locked Investigator Biography. It includes short, medium, and expanded profile variants, role descriptions, interview introduction, media background paragraph, education/professional table, Krytronx positioning, tone controls, claim boundaries, website layout, press-kit placement, and quality checks.

## Consistency checks

- Identifies P. Dwayne Esterline as owner and Principal of Krytronx, LLC.
- Identifies Esterline as discoverer of the K-field.
- Preserves the June 2026 discovery timing.
- Preserves Huntington University and Indiana Wesleyan University education references.
- Preserves the approved purchasing leadership detail: approximately one billion dollars in annual spend across multiple North American facilities, with staff located in Monroe, Michigan.
- Excludes the removed Cost Reduction Guide detail.
- Preserves Krytronx as an independent research firm focused on further development of the K-field discovery.
- Maintains the Mass Bridge as the public focal point.

## Trade-secret and privacy boundary check

PASS.

The profile does not include proprietary geometry, derivation details, witness tables, internal computational machinery, unreleased devices, private personal details, or unapproved affiliations.

## Review items

- Confirm whether the preferred public title should be “Principal Investigator, K-field Discovery” or “Discoverer of the K-field.”
- Confirm whether “owner and Principal” should be used in the short profile or reserved for the expanded profile.
- Confirm whether the one-billion-dollar purchasing responsibility should remain in the public profile.
- Confirm whether the selected Mass Bridge quote should remain as the recommended profile pairing.

## Locking condition

Upon approval, Item 21 should be marked LOCKED and used as the public Principal Investigator Profile. No subsequent package item should proceed until approval is received.
